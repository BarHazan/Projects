-- CLEAR the DATABASE:
DROP TABLE REVIEWS
DROP TABLE RESERVATIONS
DROP TABLE ROOMS
DROP TABLE HOTELS
DROP TABLE SEARCHES
DROP TABLE CUSTOMERS


CREATE TABLE CUSTOMERS(
Email varchar(30) NOT NULL PRIMARY KEY,
Name_First varchar(30) NOT NULL,
Name_Last varchar(30) NOT NULL,
Phone varchar(30) NULL,
Gender varchar(1) NOT NULL,
Country varchar(30) NOT NULL,
User_Password varchar(30) NOT NULL,
Agoda_Points integer NULL DEFAULT 0,
Joined_Date date NOT NULL,
CONSTRAINT CK_Email CHECK (Email LIKE '%@%.%'),
)

CREATE TABLE SEARCHES(
Search_DT datetime NOT NULL PRIMARY KEY,
Num_of_PPL integer NOT NULL,
Date_Begin date NOT NULL,
Date_End date NOT NULL,
Destination varchar(30) NOT NULL,
Placed_By varchar(30) NOT NULL,
CONSTRAINT FK_placed_by FOREIGN KEY (Placed_By) REFERENCES CUSTOMERS (Email),
CONSTRAINT CK_Num_of_PPL CHECK (Num_of_PPL BETWEEN 1 AND 36),
CONSTRAINT CK_Dates CHECK (Date_Begin < Date_End),
)


CREATE TABLE HOTELS(
Hotel_Name varchar(30) NOT NULL,
Address_Street	varchar(30)	NOT NULL,
Address_Number integer NOT NULL,
Address_City varchar(30) NOT NULL,
Address_Country varchar(30) NOT NULL,
Zip_Code integer  NULL, 
Phone varchar(30) NULL,
Email varchar(30) NOT NULL,
CONSTRAINT PK_HOTELS PRIMARY KEY(Hotel_Name, Address_Street ,Address_Number , Address_City , Address_Country ),
CONSTRAINT CK_Hotel_Email CHECK (Email LIKE '%@%.%'),
CONSTRAINT CK_ADDRESS_NUMBER CHECK (Address_Number > 0 ), 
)

CREATE TABLE ROOMS(
Hotel_Name varchar(30) NOT NULL,
Address_Street	varchar(30) NOT NULL,
Address_Number integer NOT NULL,
Address_City varchar(30) NOT NULL,
Address_Country varchar(30) NOT NULL,
Room_Type varchar(30) NOT NULL, 
Room_Capacity integer  NOT NULL,
Price float NOT NULL,
Quantity_Of_Room_Type integer  NOT NULL default 1,
Commission float NOT NULL,
CONSTRAINT PK_ROOMS PRIMARY KEY(Hotel_Name, Address_Street ,Address_Number , Address_City , Address_Country,Room_Type),   
CONSTRAINT fk_HOTELS_ROOMS FOREIGN KEY(Hotel_Name,Address_Street,Address_Number, Address_City,Address_Country) REFERENCES HOTELS(Hotel_Name,Address_Street,Address_Number, Address_City,Address_Country),
CONSTRAINT Check_Room_Capacity CHECK (Room_Capacity BETWEEN 1 AND 12),
)

CREATE TABLE RESERVATIONS(
Reservation_ID integer NOT NULL PRIMARY KEY,
Requests varchar(100) NULL,
Is_Upgraded bit NOT NULL,
Upgrade_Offer float NULL default 0,
Is_Proposal bit NULL default 0,
Search_DT datetime NOT NULL,
Hotel_Name varchar(30) NOT NULL,
Address_Street	varchar(30) NOT NULL,
Address_Number integer NOT NULL,
Address_City varchar(30) NOT NULL,
Address_Country varchar(30) NOT NULL,
Room_Type varchar(30) NOT NULL, 

CONSTRAINT FK_Reservation_search FOREIGN KEY (Search_DT) REFERENCES SEARCHES(Search_DT),
CONSTRAINT FK_Reservation_rooms FOREIGN KEY (Hotel_Name,Address_Street,Address_Number,Address_City,Address_Country,Room_Type)
		   REFERENCES ROOMS(Hotel_Name,Address_Street,Address_Number,Address_City,Address_Country,Room_Type), 

)

CREATE TABLE REVIEWS(
Hotel_Name varchar(30) NOT NULL,
Address_Street varchar(30) NOT NULL,
Address_Number integer NOT NULL,
Address_City varchar(30) NOT NULL,
Address_Country varchar(30) NOT NULL,
Review_DT datetime NOT NULL,
Rating integer NOT NULL,
Review_Description varchar(100) NULL,
Written_On integer NOT NULL,
CONSTRAINT PK_REVIEWS PRIMARY KEY(Hotel_Name, Address_Street ,Address_Number , Address_City , Address_Country,Review_DT),   
CONSTRAINT FK_HOTELS_REVIEWS FOREIGN KEY(Hotel_Name,Address_Street,Address_Number, Address_City,Address_Country) 
			REFERENCES HOTELS(Hotel_Name,Address_Street,Address_Number, Address_City,Address_Country), 
CONSTRAINT FK_Written_On FOREIGN KEY(Written_On) REFERENCES RESERVATIONS(Reservation_ID),
CONSTRAINT CK_Rating_Reviews CHECK (Rating BETWEEN 0 AND 10) 
)