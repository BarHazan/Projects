DROP TABLE COUNTRIES

CREATE TABLE COUNTRIES(
Country_Name varchar(30) NOT NULL,
Country_Year integer NOT NULL,
Country_Population integer NOT NULL,
Area float NOT NULL,
GDP_For_Year float NOT NULL,
CONSTRAINT PK_ROOMS PRIMARY KEY(Country_Name, Country_Year))