
public class MaintenanceEmployee extends Employee{
	
	private double UnionRate;
	
	
	
	public MaintenanceEmployee(int id, String profession, String name, int age, double unionRate) {
		super( id, profession, name, age);
		UnionRate = unionRate;
		updateSalary();
	}
	
	public void updateSalary() {
		Salary = 2500*(1 + UnionRate);
	}
}
