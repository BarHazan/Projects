import java.io.IOException;

public class GenderException extends IOException{
	
	public GenderException () {
		super ("Wrong costumer gender");
	}
}