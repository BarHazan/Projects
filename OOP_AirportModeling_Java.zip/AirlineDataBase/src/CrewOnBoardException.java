import java.io.IOException;

public class CrewOnBoardException extends IOException {


	public CrewOnBoardException (String message) {
		super (message);
	}
}
