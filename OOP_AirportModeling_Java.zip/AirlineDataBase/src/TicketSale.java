
public class TicketSale implements Comparable<TicketSale>{
	
	private String Flight ;
	private int SoldTo;
	private int SoldBy;
	private int NumberOfTickets;
	private String Site;
	private boolean SaleBySite;
	
	public TicketSale( String flight ,int soldTo,int soldBy,int numberOfTickets,String site) {
		Flight = flight;
		SoldTo = soldTo;
		SoldBy = soldBy;
		NumberOfTickets = numberOfTickets;
		Site = site;
		if (SoldBy!=0) 
			SaleBySite = false;
		else SaleBySite = true;
	}
	
	public String getFlight() {
		return Flight;
	}
	public int getSoldBy() {
		return SoldBy;
	}
	
	public int getNumOfTickets() {
		return NumberOfTickets;
	}
	
	public boolean getSaleBySite() {
		return SaleBySite;
	}
	
	public int compareTo(TicketSale ticket) {
		return Flight.compareTo(ticket.getFlight());
	}
	
	
}
