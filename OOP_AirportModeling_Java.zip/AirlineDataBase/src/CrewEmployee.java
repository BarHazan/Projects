
public class CrewEmployee extends Employee implements Comparable<CrewEmployee> {

	private double EshelRate;
	private int numOfFlights;
	
	
 
	public CrewEmployee(int id, String profession, String name, int age, double eshelrate) {
		super( id, profession, name, age);
		EshelRate = eshelrate;
		updateSalary();
	}
	
	public void updateSalary() {
		if (Profession.compareTo("Pilot")==0)
			Salary = 7500*(1+EshelRate*numOfFlights);
		if (Profession.compareTo("Flight Attendant")==0)
			Salary = 3500*(1+EshelRate*numOfFlights);
		if (Profession.compareTo("Security")==0)
			Salary = 5500*(1+EshelRate*numOfFlights);
	}
	
	public String getProfession() {
		return Profession;
	}
	
	public int compareTo(CrewEmployee other) {
		if (numOfFlights > other.numOfFlights) return 1;
		if (numOfFlights < other.numOfFlights) return -1;
		else return 0;
	}
	
	public void addFlight() {
		numOfFlights++;
		updateSalary();
	}
	
	
}
