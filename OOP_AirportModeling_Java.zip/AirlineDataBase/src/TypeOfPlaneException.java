import java.io.IOException;

public class TypeOfPlaneException extends IOException {
	
    public  TypeOfPlaneException () {
        super ("Valid Type of plane");
    }
}