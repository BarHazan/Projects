
public class MarketingEmployee extends Employee{
	private String Phone;
	private final int BonusForSale=15;
	private final int BonusForsign=20;
	private int numOfSales;
	private int numOfSigns;
	
	public MarketingEmployee(int id, String profession, String name, int age, String phone) {
		super( id, profession, name, age);
		Phone = phone;
		updateSalary();
	}
	
	public int getID() {
		return ID;
	}
	
	public void addSale() {
		numOfSales++;
		updateSalary();

	}
	
	public void addSign() {
		numOfSigns++;
		updateSalary();
	}
	
	public void updateSalary() {
		Salary = BonusForSale*numOfSales + BonusForsign*numOfSigns;
	}
	
	
}
