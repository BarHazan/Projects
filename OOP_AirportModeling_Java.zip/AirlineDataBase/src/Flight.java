
public class Flight implements Comparable<Flight>{
	
	private String Number;
	private String Type;
	private String Destination;
	private int PricePerTicket;
	
	private CrewEmployee[] Pilots;
	private CrewEmployee[] FlightAttendants;
	private CrewEmployee[] Security;
	
	public Flight(String number,String type, String destination,int pricePerTicket) {
		Number = number;
		Type = type;
		Destination = destination;
		PricePerTicket = pricePerTicket;
		BuidCrewByTYpe();
	}
	
	private void BuidCrewByTYpe() {
		if (Type.compareTo("777")==0)
			set777Crew();
		if (Type.compareTo("737")==0)
			set737Crew();
		if (Type.compareTo("747")==0)
			set747Crew();
	}
	
	private void set777Crew() {
		Pilots = new  CrewEmployee[2];
		FlightAttendants = new  CrewEmployee[4];
		Security = new  CrewEmployee[2];
	}
	
	private void set737Crew() {
		Pilots = new  CrewEmployee[2];
		FlightAttendants = new  CrewEmployee[3];
		Security = new  CrewEmployee[1];
	}

	private void set747Crew() {
		Pilots = new  CrewEmployee[3];
		FlightAttendants = new  CrewEmployee[2];
		Security = new  CrewEmployee[2];
	}
	public int getNumOfPilots() {
		return Pilots.length; 
	}
	
	public int getNumOfFlightAttendants() {
		return FlightAttendants.length; 
	}
	
	public int getNumOfSecuritys() {
		return Security.length; 
	}
	public String getFlightNum() {
		return Number;
	}
	public int getTicketPrice() {
		return PricePerTicket;
	}
	
	public String getDestination() {
		return Destination;
	}
	
	
	public int compareTo(Flight other) {
		if (PricePerTicket > other.PricePerTicket) return 1;
		if (PricePerTicket < other.PricePerTicket) return -1;
		else return 0;
	}
	
	public void setPilot(CrewEmployee pilot) throws CrewOnBoardException {
		 for (int i = 0; i < Pilots.length; i++) {
			 if (Pilots[i]==null) {
				 Pilots[i]=pilot;
				 pilot.addFlight();
			 }
			 if (i == Pilots.length-1 && Pilots[i]!=null) 
				 throw new CrewOnBoardException("Flight number" + Number + " with plane" + Type +  " has " + Pilots.length + " Pilots already");
		 }
	}
	
	public void setFlightAttendant(CrewEmployee flightAttendent) throws CrewOnBoardException  {
		 for (int i = 0; i < FlightAttendants.length; i++) {
			 if (FlightAttendants[i]==null) {
				 FlightAttendants[i]=flightAttendent;
				 flightAttendent.addFlight();
			 }
			 if (i == FlightAttendants.length-1 && FlightAttendants[i]!=null) 
				 throw new CrewOnBoardException("Flight number" + Number + " with plane" + Type +  " has " + FlightAttendants.length + " Flight Attendents already");
		 }
	}
	
	
	public void setSecurity(CrewEmployee security) throws CrewOnBoardException {
		 for (int i = 0; i < Pilots.length; i++) {
			 if (Security[i]==null) {
				 Security[i]=security;
				 security.addFlight();
			 }
			 if (i == Security.length-1 && Security[i]!=null) 
				 throw new CrewOnBoardException("Flight number" + Number + " with plane" + Type +  " has " + Security.length + " Security crew members already");
		 }
	}
	
	public String toString() {
		return "Flight: " + Number;
	}
}
