import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Airline {
	private ArrayList <Flight> Flights= new ArrayList <Flight>();
	private ArrayList <Employee> Employees= new ArrayList <Employee>();
	private ArrayList <Customer> Customers= new ArrayList <Customer>();
	private ArrayList <TicketSale> TicketSales= new ArrayList <TicketSale>();
	private String line; // for reading a file


	public Airline (String flights, String employees, String customers , String ticketsSales) { // Airline constructor
		readFiles (flights , employees , employees , ticketsSales);
	}


	private void readFiles (String flights, String employees, String customers , String ticketsSales) { // read files functions
		String File = flights; //first file
		int counter = 0; // read 4 files
		while (counter < 4) {
			try (FileReader reader = new FileReader(File);
					BufferedReader br = new BufferedReader(reader)) {  

				int counter2 = 0;
				while ((line = br.readLine()) != null) { // read line by line
					if (counter2 > 0) { //to skip the first line in each file for headlines
						if (counter == 0)
							newFlight();
						else if (counter == 1)
							newEmployee();
						else if (counter == 2)
							newCustomer();
						else
							newTicketSale();
					}
					counter2++;
				}
			} catch (FileNotFoundException e) { //if the file was not found
				System.out.println("The file " + File + " was not found.");
			} catch (IOException e) {
				System.out.println(" Caught IOException:" + e.getMessage());
			}
			counter++;
			if (counter == 1) { //second file
				File = employees;
				//***** sort(copsArrayList, Collections.reverseOrder());//sorting cops by experience in descending order
			} else if (counter == 2) { //third file
				File = customers;
				//**** sort(vehicleArrayList, Collections.reverseOrder());//sorting vehicles by speed in descending order
			}
			else {
				File = ticketsSales; //fourth file
			}
		}
	}


	private void newFlight() throws TypeOfPlaneException { //add new flight to the ArrayList of flights
		String[] info = line.split("\t"); //creating an information array
		String number = info[0];
		String type = info[1];
		String destination = info [2];
		int pricePerTicket = Integer.parseInt(info[3]);
		if (!(type.equals("747") || type.equals("737") || type.equals("777"))) {
			throw new TypeOfPlaneException ();

		}
		Flights.add (new Flight (number , type , destination , pricePerTicket)); 
	}


	private void newEmployee() throws WrongPhoneNumberException {
		String[] info = line.split("\t"); //creating an information array
		int id = Integer.parseInt(info [0]);
		String profession = info [1];
		String name = info[2];
		int age = Integer.parseInt(info [3]);

		if (profession.equals("Marketing")) {
			String phone = info [5];
			if (phone.charAt(0) != '0' || phone.length() != 10) {
				throw new WrongPhoneNumberException ();
			}
			Employees.add (new MarketingEmployee (id , profession, name , age  , phone));
		}
		else if (profession.equals("Maintenance")) {
			double bonusRateForSale = Double.parseDouble(info[4]);
			Employees.add (new MaintenanceEmployee (id , profession, name , age  , bonusRateForSale));
		}
		else {
			double bonusRateForSale = Double.parseDouble(info[4]);
			Employees.add (new CrewEmployee (id , profession, name , age  , bonusRateForSale));
		}

	}


	private void newCustomer() throws GenderException {
		String[] info = line.split("\t"); //creating an information array
		int id = Integer.parseInt(info [0]);
		String name = info [1];
		int age = Integer.parseInt(info [2]);
		char gender = info [3].charAt(0);
		if (gender != 'f' && gender != 'm') { 
			throw new GenderException();

		}

		int registeredBy = Integer.parseInt(info [4]);

		Customers.add (new Customer(id , name , age , gender , registeredBy));
	}


	private void newTicketSale() {
		String[] info = line.split("\t"); //creating an information array
		String flightNumber = info [0];
		int soldTo = Integer.parseInt(info [1]);
		int soldBy;
		if (info[2] == null)
			soldBy = 0;
		else 
			soldBy = Integer.parseInt(info [2]);
		int numberOfTickets = Integer.parseInt(info [3]);
		String site = info [4]; // if there is no web site its null

		TicketSales.add (new TicketSale (flightNumber , soldTo , soldBy , numberOfTickets , site));

		for ( int i = 0; i < Customers.size(); i++) {
			if (Customers.get(i).getID()==soldTo)
				Customers.get(i).addToTicketHistory(TicketSales.get(TicketSales.size()-1));
		}
	}


	public void setCrewToFlights() throws CrewOnBoardException {
		Collections.sort(Flights);
		ArrayList <CrewEmployee> Pilots = ArrayListByProfession("Pilot");
		ArrayList <CrewEmployee> FlightAttendants = ArrayListByProfession("Flight Attendant");
		ArrayList <CrewEmployee> Securitys = ArrayListByProfession("Security");


		for (int i = Flights.size()-1 ; i >= 0 ; i--) {
			for (int j = Flights.get(i).getNumOfPilots() ; j > 0 ; j--) {
				Flights.get(i).setPilot(Pilots.get(0));
				Collections.sort(Pilots);
			}
			for (int k = Flights.get(i).getNumOfFlightAttendants() ; k > 0 ; k--) {
				Flights.get(i).setFlightAttendant(FlightAttendants.get(0));
				Collections.sort(FlightAttendants);
			}

			for (int t = Flights.get(i).getNumOfSecuritys() ; t > 0 ; t--) {

				Flights.get(i).setSecurity(Securitys.get(0));
				Collections.sort(Securitys);

			}
		}	
	}

	private ArrayList <CrewEmployee> ArrayListByProfession (String Profession) {
		ArrayList <CrewEmployee> CrewEmployees= new ArrayList <CrewEmployee>();
		for (int i = 0 ; i < Employees.size() ; i ++) {
			if (Employees.get(i).getProfession().equals(Profession)) {
				CrewEmployees.add((CrewEmployee) Employees.get(i));
			}
		}
		return CrewEmployees;
	}


	public void setEmployeesSalaryEvents() { //method that updates salary referred events. for crew-numOfFlights,
		// for marketing-number of sales and signs
		updateMarketingSuccess();
		for (int i = 0; i < Employees.size(); i++) {
			Employees.get(i).updateSalary();
		}
	}

	private ArrayList <MarketingEmployee> ArrayListOfMarketing (String Profession) {
		ArrayList <MarketingEmployee> MarketingEmployees= new ArrayList <MarketingEmployee>();
		for (int i = 0 ; i < Employees.size() ; i ++) {
			if (Employees.get(i).getProfession().equals(Profession)) {
				MarketingEmployees.add((MarketingEmployee) Employees.get(i));
			}
		}
		return MarketingEmployees;
	}

	private void updateMarketingSuccess() {
		ArrayList <MarketingEmployee> Marketings = ArrayListOfMarketing("Marketing");
		for (int i = 0; i < TicketSales.size(); i++) {
			int x= TicketSales.get(i).getSoldBy();
			for (int j = 0; j < Marketings.size(); j++) {
				if (Marketings.get(j).getID()==x) 
					Marketings.get(j).addSale();
			}
		}
		for (int i = 0; i < Customers.size(); i++) {
			int x= Customers.get(i).getRegisteredBy();
			for (int j = 0; j < Marketings.size(); j++) {
				if (Marketings.get(j).getID()==x) 
					Marketings.get(j).addSign();
			}
		}
	}



	public void printCustomerActivity(int id) {
		System.out.println("Costumer name: " + id);
		System.out.println("Flight list:");
		for (int i = 0; i < Customers.size(); i++) {
			if (Customers.get(i).getID()==id) {
				for (int j = 0; j < Customers.get(i).getTicketHistory().size(); j++) { 
					String flight = Customers.get(i).getTicketHistory().get(j).getFlight();
					System.out.println("Flight" + flight + " ");
					for (int k = 0; k < Flights.size(); k++) {
						if (Flights.get(k).getFlightNum()==flight) {
							System.out.print(Flights.get(k).getTicketPrice());
							break;
						}		
					}

				}
			}

		}
		System.out.println("Total expense is: " + TotalExpensePerCostumer(id));
	}

	public int TotalExpensePerCostumer(int id) {
		int totalExpense = 0;
		for (int i = 0; i < Customers.size(); i++) {
			if (Customers.get(i).getID()==id) {
				for (int j = 0; j < Customers.get(i).getTicketHistory().size(); j++) { 
					String flight = Customers.get(i).getTicketHistory().get(j).getFlight();
					for (int k = 0; k < Flights.size(); k++) {
						if (Flights.get(k).getFlightNum()==flight) {
							totalExpense += Flights.get(k).getTicketPrice()*Customers.get(i).getTicketHistory().get(j).getNumOfTickets();
							break;
						}		
					}

				}
			}

		}
		return totalExpense;
	}


	public void printPotentialCustomersDetails(ArrayList <Integer> IDs) {

		ArrayList <CustomerExpense> CustomerIDs= new ArrayList <CustomerExpense>();

		for (int i = 0; i < IDs.size(); i++) {
			int id = IDs.get(i);
			for (int j = 0; j < Customers.size(); j++) {
				if (Customers.get(j).getID()==id) 
					CustomerIDs.add(new CustomerExpense(id, TotalExpensePerCostumer(id)));
			}
		}
		Collections.sort(CustomerIDs, Collections.reverseOrder());
		printPotentialCustomersByRank(CustomerIDs);

	}

	public void printPotentialCustomersByRank(ArrayList <CustomerExpense> customerIDs) {
		System.out.println("Costumer potential: ");
		for (int i = 0; i < customerIDs.size(); i++) {
			System.out.println("Rank-" + i + ". " + customerIDs.get(i).getID());
		}
	}


	public void printAgeReport(String a) {//assuming costumer didn't fly to the destination twice
		System.out.println("Destination: " + a);
		ArrayList <Integer> AgesToDestination= new ArrayList <Integer>();
		for (int i = 0; i < Customers.size(); i++) {
			for (int j = 0; j < Customers.get(i).getTicketHistory().size(); j++) { 
				String flight = Customers.get(i).getTicketHistory().get(j).getFlight();
				for (int k = 0; k < Flights.size(); k++) {
					if (Flights.get(k).getFlightNum().compareTo(flight)==0 && Flights.get(k).getDestination().compareTo(a)==0) 
						AgesToDestination.add(new Integer(Customers.get(i).getAge()));
				}
			}
		}
		int A=0,B=0,C=0,D=0,E=0;
		for (int i = 0; i < AgesToDestination.size(); i++) {
			if (AgesToDestination.get(i)>=0 && AgesToDestination.get(i)<=15) A++;
			if (AgesToDestination.get(i)>=16 && AgesToDestination.get(i)<=21) B++;
			if (AgesToDestination.get(i)>=22 && AgesToDestination.get(i)<=30) C++;
			if (AgesToDestination.get(i)>=31 && AgesToDestination.get(i)<=45) D++;
			if (AgesToDestination.get(i)>=46 && AgesToDestination.get(i)<=85) E++;
		}

		System.out.println("0-15:"+ A/AgesToDestination.size() + "%");
		System.out.println("16-21:"+ B/AgesToDestination.size() + "%");
		System.out.println("22-30:"+ C/AgesToDestination.size() + "%");
		System.out.println("31-45:"+ D/AgesToDestination.size() + "%");
		System.out.println("46-85:"+ E/AgesToDestination.size() + "%");
	}

	public double getOnlineProportions() {
		int onLine = 0;
		for (int i = 0; i < TicketSales.size(); i++) {
			if (TicketSales.get(i).getSaleBySite()) onLine++;
		}

		return (double)onLine/TicketSales.size();
	}

	public double getBalance() {
		double incomes = 0;
		for (int i = 0; i < Customers.size(); i++) {
			incomes += (double)TotalExpensePerCostumer(Customers.get(i).getID()); 
		}
		double expense = 0;
		for (int i = 0; i < Employees.size(); i++) {
			expense += Employees.get(i).getSalary();
		}
		return incomes-expense;
	}
	
	public void airlineReport() {
		System.out.println("Airline Report");
		System.out.println("Workers list:");
		for (int i = 0; i < Employees.size(); i++) 
			System.out.println(Employees.get(i).toString());
		System.out.println("....................");
		System.out.println("Flights list:");
		for (int i = 0; i < Flights.size(); i++) 
			System.out.println(Flights.get(i).toString());
		System.out.println("....................");
		System.out.println("Customers list:");
		for (int i = 0; i < Customers.size(); i++) 
			System.out.println(Customers.get(i).toString());
	}

}
