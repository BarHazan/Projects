import java.util.ArrayList;
import java.util.Collections;

public class Customer  {
	private int ID ;
	private String Name;
	private int Age;
	private char Gender;
	private int RegisteredBy;
	private ArrayList <TicketSale> TicketHistory = new ArrayList <TicketSale>();

	public Customer(int id,  String name, int age,char gender, int registeredBy) throws GenderException {
		if (gender != 'f' && gender != 'm') 
			throw new GenderException();
		ID = id;
		Name = name;
		Age = age;
		Gender = gender;
		RegisteredBy = registeredBy;
	}
	
	
	public char getGender() {
		return Gender;
	}
	
	public int getRegisteredBy() {
		return RegisteredBy;
	}
	
	public int getID() {
		return ID;
	}
	public int getAge() {
		return Age;
	}
	
	
	public void addToTicketHistory(TicketSale ticket) {
		TicketHistory.add(ticket);
		Collections.sort(TicketHistory);
	}
	
	public ArrayList <TicketSale> getTicketHistory(){
		return TicketHistory;
	}
	
	public void PrintTickets() {
		for (int i = 0; i < TicketHistory.size(); i++) { 
			System.out.println(TicketHistory.get(i).getFlight());
		
		}
	}
	
	public String toString() {
		return "Name: " + Name + "Age: " + Age + "Gender: " + Gender;
	}
}
