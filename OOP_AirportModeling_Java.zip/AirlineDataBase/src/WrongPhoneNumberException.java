import java.io.IOException;

public class WrongPhoneNumberException extends IOException{
	
	public  WrongPhoneNumberException () {
        super ("Wrong phone number");
    }
}