
public class CustomerExpense implements Comparable<CustomerExpense>{
	private int ID;
	private int Expense;

	public CustomerExpense(int id, int expense) {
		ID = id;
		Expense = expense;
	}
	
	public int getExpense() {
		return Expense;
	}
	
	public int getID() {
		return ID;
	}
	
	public int compareTo(CustomerExpense other) {

		if (Expense > other.getExpense()) return 1;
		if (Expense < other.getExpense()) return -1;
		else return 0;
	}

}
