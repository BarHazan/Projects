
abstract public class Employee {
	protected int ID ;
	protected String Profession;
	protected String Name;
	protected int Age;
	protected double Salary;

	public Employee(int id, String profession, String name, int age) {
		ID = id;
		Profession = profession;
		Name = name;
		Age = age;
	}

	public String getProfession() {
		return Profession;
	}
	
	abstract public void updateSalary() ;
	
	public double getSalary() {
		return Salary;
	}
	
	public String toString() {
		return "Name: " + Name + "Age: " + Age;
	}
}
