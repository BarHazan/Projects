-- Deleting the DATABASE:
DROP TABLE RETRIEVES_HOTELS
DROP TABLE RETRIEVES_FLIGHTS
DROP TABLE FAVORS

DROP TABLE REVIEWS
DROP TABLE RESERVATIONS
DROP TABLE RESERVATION_REQUESTS -- LU 


DROP TABLE ROOMS_FACILITIES
DROP TABLE ROOMS_FACILITIES_LOOKUP -- LU
DROP TABLE HOTELS_FACILITIES 
DROP TABLE HOTELS_FACILITIES_LOOKUP -- LU 
DROP TABLE ROOMS
DROP TABLE ROOM_TYPES -- LU
DROP TABLE HOTELS

DROP TABLE SEARCHS
DROP TABLE CABIN_CLASSES -- LU
DROP TABLE VACATION_TYPES --LU 


DROP TABLE FLIGHTS


DROP TABLE CREDIT_CARDS
DROP TABLE LOOK_UP_EXPIRY_MONTH-- LU
DROP TABLE LOOK_UP_EXPIRY_YEAR -- LU 

DROP TABLE REGISTERED_CUSTOMERS
DROP TABLE CUSTOMERS
DROP TABLE GENDER -- LU 
DROP TABLE COUNTRIES -- LU




--Creating the DATABASE:
CREATE TABLE GENDER(           -- LOOKUP 
Gender char(1) NOT NULL PRIMARY KEY, 
)



CREATE TABLE COUNTRIES (        --LOOKUP 
Country varchar(30) NOT NULL  PRIMARY KEY,
)


CREATE TABLE CUSTOMERS(
Email varchar(40) NOT NULL PRIMARY KEY,
Name_First varchar(30) NOT NULL,
Name_Last varchar(30) NOT NULL,
Phone varchar(30) NULL,
Gender char NOT NULL,
Country varchar(30) NOT NULL,
CONSTRAINT CK_Email CHECK (Email LIKE '%@%.%'),
CONSTRAINT LU_Gender FOREIGN KEY (Gender) REFERENCES GENDER(Gender),
CONSTRAINT LU_Countries FOREIGN KEY (Country) REFERENCES COUNTRIES (Country),
)




CREATE TABLE REGISTERED_CUSTOMERS(
Email varchar(40) NOT NULL PRIMARY KEY,
User_Password varchar(30) NOT NULL,
Agoda_Points integer NULL DEFAULT 0,
Seniority varchar(30) NOT NULL DEFAULT 0,
CONSTRAINT fk_EMAIL FOREIGN KEY (Email) REFERENCES CUSTOMERS(Email),
CONSTRAINT Check_Password CHECK (DATALENGTH(User_Password)>5),
CONSTRAINT Check_Password2 CHECK (DATALENGTH(User_Password)<13),
 
)

CREATE TABLE CABIN_CLASSES(      -- LOOKUP 
Cabin_Class varchar(30) NOT NULL PRIMARY KEY,
)

CREATE TABLE VACATION_TYPES( -- LOOKUP
Vacation_Type varchar(30) NOT NULL  PRIMARY KEY, 
) 



CREATE TABLE SEARCHS(
Search_DT datetime NOT NULL,
IP_Address varchar(30) NOT NULL, 
Is_Hotel_Search bit NOT NULL , 
Num_of_Adults integer NOT NULL DEFAULT 2,
Num_of_Children integer NOT NULL DEFAULT 0 , 
Date_Begin date NOT NULL,
Date_End date NOT NULL,
Origin varchar(30)  NULL,
Destination varchar(30) NOT NULL,
Cabin_Class varchar(30) NULL,
Vacation_Type varchar(30) NULL,   
CONSTRAINT PK_SEARCH PRIMARY KEY(Search_DT,IP_Address),   
CONSTRAINT CK_Num_OF_Adults CHECK (Num_of_Adults BETWEEN 1 AND 36),
CONSTRAINT CK_Num_Of_Children CHECK (Num_of_Children BETWEEN 0 AND 9), 
CONSTRAINT CK_Dates CHECK (Date_Begin < Date_End),
CONSTRAINT CK_Date_Begin CHECK (Date_Begin > CONVERT(DATE, GETDATE())),
CONSTRAINT LU_Cabin_Classes FOREIGN KEY (Cabin_Class) REFERENCES CABIN_CLASSES (Cabin_Class),
CONSTRAINT LU_Vacation_Type FOREIGN KEY (Vacation_Type) REFERENCES VACATION_TYPES (Vacation_Type), 
CONSTRAINT CK_IP_Address CHECK (IP_Address LIKE '%.%.%.%'),
)



CREATE TABLE HOTELS(
Name varchar(50) NOT NULL ,
Address_Street	varchar(50)		NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
Zip_Code integer  NULL, 
Phone varchar(30) NULL,
Email varchar(50) NOT NULL,
CONSTRAINT PK_HOTELS PRIMARY KEY(Name, Address_Street ,Address_Number , Address_City , Address_Country ),
CONSTRAINT CK_Hotel_Email CHECK (Email LIKE '%@%.%'),
CONSTRAINT CK_ADDRESS_NUMBER CHECK (Address_Number > 0 ) , 
)





CREATE TABLE ROOM_TYPES(
Room_Type varchar(30) NOT NULL PRIMARY KEY,
)


CREATE TABLE ROOMS(
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
Room_Type varchar(30) NOT NULL , 
Room_Capacity integer  NOT NULL ,
Price decimal(10,2) NOT NULL,
Quantity_of_Room_Types integer  NOT NULL default 0 , 
CONSTRAINT PK_ROOMS PRIMARY KEY(Name, Address_Street ,Address_Number , Address_City , Address_Country,Room_Type),   
CONSTRAINT fk_HOTELS_ROOMS FOREIGN KEY(Name,Address_Street,Address_Number, Address_City,Address_Country) REFERENCES HOTELS(Name,Address_Street,Address_Number, Address_City,Address_Country),
CONSTRAINT Check_Room_Capacity CHECK (Room_Capacity BETWEEN 1 AND 12),
CONSTRAINT LU_Room_Types FOREIGN KEY (Room_Type) REFERENCES ROOM_TYPES (Room_Type),
)

CREATE TABLE FLIGHTS(
Flight_Number varchar(10) NOT NULL PRIMARY KEY,
Origin varchar(30) NOT NULL, 
Destenation varchar(30) NOT NULL,
DT_Depart datetime NOT NULL,
DT_Arrival datetime NOT NULL, 
CONSTRAINT CK_DT_Depart_Arrival CHECK (DT_Depart < DT_Arrival),
CONSTRAINT CK_DT_Depart CHECK (DT_Depart > GetDate()),
)


CREATE TABLE LOOK_UP_EXPIRY_MONTH(
Expiry_Month varchar(2) NOT NULL PRIMARY KEY, 
) 

CREATE TABLE LOOK_UP_EXPIRY_YEAR(
Expiry_Year varchar(4) NOT NULL PRIMARY KEY, 
) 


CREATE TABLE CREDIT_CARDS(
Card_Number varchar(16) NOT NULL PRIMARY KEY,
Expiry_Month varchar(2)  NOT NULL,
Expiry_Year varchar(4) NOT NULL,
CVV varchar(3) NOT NULL,
CONSTRAINT Check_Expiry CHECK (Expiry_Year > YEAR(GetDate())  OR ( Expiry_Year = YEAR(GetDate()) AND Expiry_Month > MONTH(GetDate()) ) ) ,  
CONSTRAINT Check_CVV CHECK (CVV LIKE '[0-9][0-9][0-9]'), 
CONSTRAINT Check_Card_Number CHECK (Card_Number LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
CONSTRAINT LU_Expiry_Month FOREIGN KEY (Expiry_Month) REFERENCES  LOOK_UP_EXPIRY_MONTH (Expiry_Month), 
CONSTRAINT LU_Expiry_Year FOREIGN KEY (Expiry_Year) REFERENCES LOOK_UP_EXPIRY_YEAR(Expiry_Year),


)

CREATE TABLE RESERVATION_REQUESTS(
Requests varchar(30) NOT NULL PRIMARY KEY,
)

CREATE TABLE RESERVATIONS(
Reservation_ID integer NOT NULL PRIMARY KEY,
Requests varchar(30) NULL,
Number_OF_Rooms integer NOT NULL,
Made_By varchar(40) NOT NULL,
Paid_With varchar(16) NOT NULL, 
Retrieves_Reservation_DT datetime NOT NULL,
Retrieved_Reservation_IP varchar(30) NOT NULL, 
Ordered_In_Name varchar(50) NOT NULL ,
Ordered_In_Address_Street varchar(50) NOT NULL,
Ordered_In_Address_Number integer NOT NULL , 
Ordered_In_Address_City varchar(50) NOT NULL ,
Ordered_In_Address_Country varchar(50) NOT NULL ,
Ordered_In_Room_Type varchar(30) NOT NULL , 
CONSTRAINT fk_Paid_With FOREIGN KEY (Paid_With) REFERENCES CREDIT_CARDS(Card_Number),
CONSTRAINT fk_Made_By FOREIGN KEY (Made_By) REFERENCES CUSTOMERS(Email),
CONSTRAINT fk_RR_IP FOREIGN KEY (Retrieves_Reservation_DT,Retrieved_Reservation_IP) REFERENCES SEARCHS(Search_DT,IP_Address),
CONSTRAINT fk_Orderd_In FOREIGN KEY (Ordered_In_Name,Ordered_In_Address_Street,Ordered_In_Address_Number,Ordered_In_Address_City,Ordered_In_Address_Country,Ordered_In_Room_Type) REFERENCES ROOMS(Name,Address_Street,Address_Number,Address_City,Address_Country,Room_Type), 
CONSTRAINT Number_OF_ROOMS CHECK (Number_OF_Rooms BETWEEN 1 AND 9 ) , 
CONSTRAINT LU_Reservation_Requests FOREIGN KEY (Requests) REFERENCES RESERVATION_REQUESTS (Requests),
)


CREATE TABLE REVIEWS(
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
DT datetime NOT NULL ,
Rating integer NOT NULL,
Review_Description varchar(1000) NULL,
Written_On integer NOT NULL,
CONSTRAINT PK_REVIEWS PRIMARY KEY(Name, Address_Street ,Address_Number , Address_City , Address_Country,DT),   
CONSTRAINT fk_HOTELS_REVIEWS FOREIGN KEY(Name,Address_Street,Address_Number, Address_City,Address_Country) REFERENCES HOTELS(Name,Address_Street,Address_Number, Address_City,Address_Country), 
CONSTRAINT fk_Written_On FOREIGN KEY(Written_On) REFERENCES RESERVATIONS(Reservation_ID),
CONSTRAINT CK_Rating_Reviews CHECK (Rating BETWEEN 0 AND 10) 
)




CREATE TABLE FAVORS(
Email varchar(40) NOT NULL ,
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
CONSTRAINT PK_FAVORS PRIMARY KEY(Email,Name, Address_Street ,Address_Number , Address_City , Address_Country),   
CONSTRAINT fk_HOTELS_FAVORS FOREIGN KEY(Name,Address_Street,Address_Number, Address_City,Address_Country) REFERENCES HOTELS(Name,Address_Street,Address_Number, Address_City,Address_Country), 
CONSTRAINT fk_FAVORS_EMAIL FOREIGN KEY (Email) REFERENCES REGISTERED_CUSTOMERS(Email),
)




CREATE TABLE RETRIEVES_FLIGHTS(
Search_DT datetime NOT NULL ,
IP_Address varchar(30) NOT NULL ,
Flight_Number varchar(10) NOT NULL ,
Proceed_To_External_Site bit NOT NULL ,
CONSTRAINT PK_RETRIEVES_FLIGHTS PRIMARY KEY(Search_DT,IP_Address,Flight_Number),   
CONSTRAINT fk_SEARCH_RETRIEVES_FLIGHTS FOREIGN KEY (Search_DT,IP_Address) REFERENCES SEARCHS(Search_DT,IP_Address),
CONSTRAINT fk_FLIGHT_RETRIEVES_FLIGHTS FOREIGN KEY (Flight_Number) REFERENCES FLIGHTS(Flight_Number),
)


CREATE TABLE RETRIEVES_HOTELS(
Search_DT datetime NOT NULL ,
IP_Address varchar(30) NOT NULL ,
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
CONSTRAINT PK_RETRIEVES_HOTELS PRIMARY KEY(Search_DT,IP_Address,Name ,Address_Street,Address_Number,Address_City,Address_Country  ),   
CONSTRAINT fk_SEARCH_RETRIEVES_HOTELS FOREIGN KEY (Search_DT,IP_Address) REFERENCES SEARCHS(Search_DT,IP_Address),
CONSTRAINT fk_HOTELS_RETRIEVES_HOTELS FOREIGN KEY(Name,Address_Street,Address_Number, Address_City,Address_Country) REFERENCES HOTELS(Name,Address_Street,Address_Number, Address_City,Address_Country), 
)




CREATE TABLE HOTELS_FACILITIES_LOOKUP(
Facility varchar(30) NOT NULL  PRIMARY KEY,
) 



CREATE TABLE HOTELS_FACILITIES(
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
Facility varchar(30) NOT NULL ,
CONSTRAINT PK_HOTELS_FACILITIES PRIMARY KEY(Name ,Address_Street,Address_Number,Address_City,Address_Country,Facility),
CONSTRAINT fk_HOTELS_HOTELS_FACILITIES FOREIGN KEY (Name ,Address_Street,Address_Number,Address_City,Address_Country) REFERENCES HOTELS(Name ,Address_Street,Address_Number,Address_City,Address_Country),
CONSTRAINT LU_Hotel_Facilities FOREIGN KEY (Facility) REFERENCES HOTELS_FACILITIES_LOOKUP (Facility),
)


CREATE TABLE ROOMS_FACILITIES_LOOKUP(
Facility varchar(30) NOT NULL  PRIMARY KEY, 
)


CREATE TABLE ROOMS_FACILITIES(
Name varchar(50) NOT NULL ,
Address_Street varchar(50) NOT NULL ,
Address_Number integer NOT NULL ,
Address_City varchar(50) NOT NULL ,
Address_Country varchar(50) NOT NULL ,
Room_Type varchar(30) NOT NULL ,
Facility varchar(30) NOT NULL ,
CONSTRAINT PK_ROOMS_FACILITIES PRIMARY KEY(Name ,Address_Street,Address_Number,Address_City,Address_Country,Room_Type,Facility),
CONSTRAINT fk_ROOMS_ROOMS_FACILITIES FOREIGN KEY (Name ,Address_Street,Address_Number,Address_City,Address_Country,Room_Type) REFERENCES ROOMS(Name ,Address_Street,Address_Number,Address_City,Address_Country,Room_Type),
CONSTRAINT LU_Rooms_Facilities FOREIGN KEY (Facility) REFERENCES ROOMS_FACILITIES_LOOKUP (Facility),
)


--Inserting DATA To DATABASE Lookups:

INSERT INTO GENDER (Gender) VALUES ('M') ,('F')

INSERT INTO Countries(Country) VALUES ('Afghanistan'), ('Albania'), ('Algeria'), ('Andorra'), ('Angola'), ('Antigua & Deps'), ('Argentina'), ('Armenia'), ('Australia'), ('Austria'), ('Azerbaijan'), ('Bahamas'), ('Bahrain'), ('Bangladesh'), ('Barbados'), ('Belarus'), ('Belgium'), ('Belize'), ('Benin'), ('Bhutan'), ('Bolivia'), ('Bosnia and Herzegovina'), ('Botswana'), ('Brazil'), ('Brunei'), ('Bulgaria'), ('Burkina'), ('Burundi'), ('Cambodia'), ('Cameroon'), ('Canada'), ('Cape Verde'), ('Central African Republic'), ('Chad'), ('Chile'), ('China'), ('Colombia'), ('Comoros'), ('Congo'), ('Costa Rica'), ('Croatia'), ('Cuba'), ('Cyprus'), ('Czech Republic'), ('Denmark'), ('Djibouti'), ('Dominica'), ('Dominican Republic'), ('East Timor'), ('Ecuador'), ('Egypt'), ('El Salvador'), ('Equatorial Guinea'), ('Eritrea'), ('Estonia'), ('Ethiopia'), ('Fiji'), ('Finland'), ('France'),('French Polynesia'),('French Southern Territories'), ('Gabon'), ('Gambia'), ('Georgia'), ('Germany'), ('Ghana'), ('Greece'), ('Grenada'), ('Guatemala'), ('Guinea'), ('Guinea-Bissau'), ('Guyana'), ('Haiti'), ('Honduras'), ('Hungary'), ('Iceland'), ('India'), ('Indonesia'), ('Iran'), ('Iraq'), ('Ireland'), ('Israel'), ('Italy'), ('Ivory Coast'), ('Jamaica'), ('Japan'), ('Jordan'), ('Kazakhstan'), ('Kenya'), ('Kiribati'), ('North Korea'),('South Korea'), ('Kosovo'), ('Kuwait'), ('Kyrgyzstan'), ('Laos'), ('Latvia'), ('Lebanon'), ('Lesotho'), ('Liberia'), ('Libya'), ('Liechtenstein'), ('Lithuania'), ('Luxembourg'), ('Macedonia'), ('Madagascar'), ('Malawi'), ('Malaysia'), ('Maldives'), ('Mali'), ('Malta'), ('Marshall Islands'), ('Mauritania'), ('Mauritius'), ('Mexico'), ('Micronesia'), ('Moldova'), ('Monaco'), ('Mongolia'), ('Montenegro'), ('Morocco'), ('Mozambique'), ('Myanmar'), ('Namibia'), ('Nauru'), ('Nepal'), ('Netherlands'), ('New Zealand'), ('Nicaragua'), ('Niger'), ('Nigeria'), ('Norway'), ('Oman'), ('Pakistan'), ('Palau'), ('Panama'), ('Papua New Guinea'), ('Paraguay'), ('Peru'), ('Philippines'), ('Poland'), ('Portugal'),('Puerto Rico'), ('Qatar'), ('Romania'), ('Russia'), ('Rwanda'), ('St Kitts & Nevis'), ('St Lucia'), ('Saint Vincent & the Grenadines'), ('Samoa'), ('San Marino'), ('Sao Tome & Principe'), ('Saudi Arabia'), ('Senegal'), ('Serbia'), ('Seychelles'), ('Sierra Leone'), ('Singapore'), ('Slovakia'), ('Slovenia'), ('Solomon Islands'), ('Somalia'), ('South Africa'), ('South Sudan'), ('Spain'), ('Sri Lanka'), ('Sudan'), ('Suriname'), ('Swaziland'), ('Sweden'), ('Switzerland'), ('Syria'), ('Taiwan'), ('Tajikistan'), ('Tanzania'), ('Thailand'), ('Togo'), ('Tonga'), ('Trinidad & Tobago'), ('Tunisia'), ('Turkey'), ('Turkmenistan'), ('Tuvalu'), ('Uganda'), ('Ukraine'), ('United Arab Emirates'), ('United Kingdom'), ('United States'), ('Uruguay'), ('Uzbekistan'), ('Vanuatu'), ('Vatican City'), ('Venezuela'), ('Vietnam'),('Western Sahara'), ('Yemen'), ('Zambia'), ('Zimbabwe')

INSERT INTO CABIN_CLASSES(Cabin_Class) VALUES ('Economy'),('Business'),('First Class'),('None')

INSERT INTO VACATION_TYPES(Vacation_Type) VALUES ('Business Travelers'),('Family Travelers'),('Group Travelers'),('None') 


INSERT INTO ROOM_TYPES(Room_Type) VALUES ('Suite') , ('Double Room')  , ('Family Room')


INSERT INTO LOOK_UP_EXPIRY_MONTH(Expiry_Month) VALUES ('01'),('02'),('03'),('04'),('05'),('06'),('07'),('08'),('09'),('10'),('11'),('12')

INSERT INTO LOOK_UP_EXPIRY_YEAR(Expiry_Year) VALUES ('2020'),('2021'),('2022'),('2023'),('2024'),('2025'),('2026'),('2027'),('2028'),('2029'),('2030')


INSERT INTO RESERVATION_REQUESTS(Requests) VALUES ('Breakfast') ,( 'Airport Transport') , ('Special Occuasion')


INSERT INTO HOTELS_FACILITIES_LOOKUP (Facility) VALUES ('Free WIFI'),('Elevator'),('Swimming Pool'),('GYM'),('SPA'),('Tours'),('Coffee House'),('Bar'),('Resturants'),('Smoking Areas'),('Luggage Keeping'),('Laundry Services'),('Private Transportations'),('Car Rental')



INSERT INTO ROOMS_FACILITIES_LOOKUP (Facility) VALUES('WIFI Access'),('A/C'),('Balcony'),('Air dryer'),('Towels'),('T.V'),('Telephone'),('Smoking Allowed'),('Refreigator'),('Bath Facilities'),('Private Volt'),('Mini Bar'),('Ironing machine')


																											
-- Normal Queries: 

SELECT Gender , AVG(RE.Rating) as Average_Rating 
FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.EMAIL=R.Made_By JOIN REVIEWS AS RE ON R.Reservation_ID=RE.Written_On
WHERE COUNTRY <> 'China'
GROUP BY Gender
ORDER BY Average_Rating DESC 


SELECT RO.Room_Type , COUNT(*) AS Number_Of_Ordered_Room_Types
FROM SEARCHS AS S JOIN RESERVATIONS AS R ON S.Search_DT=R.Retrieves_Reservation_DT AND S.IP_Address = R.Retrieved_Reservation_IP JOIN ROOMS AS RO ON R.Ordered_In_Address_Street=RO.Address_Street AND R.Ordered_In_Address_Number = RO.Address_Number AND R.Ordered_In_Address_City = RO.Address_City AND R.Ordered_In_Address_Country=RO.Address_Country AND R.Ordered_In_Room_Type= RO.Room_Type
WHERE MONTH(S.Search_DT) = 7 OR MONTH(S.SEARCH_DT) = 8 
GROUP BY RO.Room_Type 
HAVING COUNT(*) > 1
ORDER BY COUNT(*) DESC 


-- Nested Queries :
SELECT H.Name , R.rating
FROM REVIEWS AS R JOIN HOTELS AS H ON R.Address_Street=H.Address_Street AND R.Address_Number=H.Address_Number AND R.Address_City=H.Address_City AND R.Address_Country=H.Address_Country
WHERE R.Rating > ( SELECT AVG(R.Rating) 
                    FROM REVIEWS AS R JOIN HOTELS AS H ON R.Address_Street=H.Address_Street AND R.Address_Number=H.Address_Number AND R.Address_City=H.Address_City AND R.Address_Country=H.Address_Country)
ORDER BY R.Rating DESC




SELECT a.Address_Country , sum(A.Total_Price) as Total_Price
FROM (	SELECT RO.Address_Country ,R.Number_OF_Rooms*RO.Price as Total_Price
		FROM RESERVATIONS AS R JOIN ROOMS AS RO ON R.Ordered_In_Address_Street=RO.Address_Street AND R.Ordered_In_Address_Number=RO.Address_Number AND R.Ordered_In_Address_City=RO.Address_City AND R.Ordered_In_Address_Country=RO.Address_Country) as a
Group By a.Address_Country
Order BY 2 DESC



-- Nested Queries with Special Tools:

ALTER TABLE RESERVATIONS
ADD Total_Price int 

UPDATE RESERVATIONS 
SET Total_Price = (
					 SELECT sum(R.Number_OF_Rooms*RO.Price)
					 FROM RESERVATIONS AS R JOIN ROOMS AS RO ON R.Ordered_In_Address_Street=RO.Address_Street AND R.Ordered_In_Address_Number=RO.Address_Number AND R.Ordered_In_Address_City=RO.Address_City AND R.Ordered_In_Address_Country=RO.Address_Country
					 WHERE  R.Reservation_ID = RESERVATIONS.Reservation_ID
					 ) 



SELECT C.Email
FROM CUSTOMERS as c join RESERVATIONS as r on c.Email = r.Made_By 
WHERE r.Total_Price IN (Select TOP 10 RES.Total_Price 
					    FROM RESERVATIONS as RES)
					     
EXCEPT 
Select EMAIL FROM REGISTERED_CUSTOMERS

-- VIEW :
CREATE VIEW CUSTOMER_RESERVATION_INFO AS
SELECT TOP 10 C.Email , sum(Total_Price) as Total_Payments
FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.Email = R.Made_By JOIN ROOMS AS RO ON R.Ordered_In_Address_Street = RO.Address_Street AND R.Ordered_In_Address_Number=RO.Address_Number AND R.Ordered_In_Address_City=RO.Address_City AND R.Ordered_In_Address_Country=RO.Address_Country
Group By C.Email
ORDER BY 2 DESC

SELECT *
FROM CUSTOMER_RESERVATION_INFO


-- FUNCTIONS :
CREATE FUNCTION CUSTOMER_RESERVATIONS123 (@CUSTOMER_ID varchar(40))
RETURNS TABLE

AS
RETURN 
   SELECT C.Email , COUNT(R.Reservation_ID) AS NUM_OF_RESERVATINOS , SUM(R.Total_Price) AS TOTAL_PAYMENTS
	  FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.Email=R.Made_By
	  WHERE C.EMAIL = @CUSTOMER_ID 
	  GROUP BY C.EMAIL

SELECT *
FROM CUSTOMER_RESERVATIONS123('aarmour41@ustream.tv')



CREATE FUNCTION GIVEN_DATE_WEAKEST_COUNTRY (@Weakest_Month int, @Weakest_Year int )
RETURNS varchar(30)
AS
BEGIN
DECLARE @NAME_OF_COUNTRY varchar(30)
                

 SELECT  @NAME_OF_COUNTRY = 	(	SELECT   COSTUME.Country	
							FROM 	( SELECT TOP 1  C.Country  , sum(R.Total_Price) AS Total_Money
									 FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.Email=R.Made_By JOIN SEARCHS AS S ON S.IP_Address=R.Retrieved_Reservation_IP AND S.Search_DT=R.Retrieves_Reservation_DT
									 WHERE MONTH(S.Search_DT) = @Weakest_Month AND YEAR(S.SEARCH_DT) = @Weakest_Year
									 GROUP BY C.Country 
									 ORDER BY 2) AS COSTUME) 


RETURN @NAME_OF_COUNTRY
END



SELECT dbo.GIVEN_DATE_WEAKEST_COUNTRY(7,2019) as Country


-- TRIGGER :
ALTER TABLE HOTELS
ADD AVERAGE_RATING INT

UPDATE HOTELS
SET AVERAGE_RATING = (
					 SELECT AVG(R.Rating)
					 FROM Reviews AS R JOIN Hotels AS H ON R.Address_Street = h .Address_Street and r.Address_Number = h.Address_Number and r.Address_City=h.Address_City and r.Address_Country=h.Address_Country
					 WHERE  R.Address_Street= HOTELS.Address_Street AND R.Address_Number=HOTELS.Address_Number AND R.Address_City=HOTELS.Address_City AND R.Address_Country=HOTELS.Address_Country
					 ) 

CREATE TRIGGER AVERAGE_HOTEL ON REVIEWS
FOR INSERT AS 
UPDATE HOTELS 
SET AVERAGE_RATING = (
					 SELECT AVG(R.Rating)
					 FROM Reviews AS R JOIN Hotels AS H ON R.Address_Street = h .Address_Street and r.Address_Number = h.Address_Number and r.Address_City=h.Address_City and r.Address_Country=h.Address_Country
					 WHERE  R.Address_Street= HOTELS.Address_Street AND R.Address_Number=HOTELS.Address_Number AND R.Address_City=HOTELS.Address_City AND R.Address_Country=HOTELS.Address_Country
					 ) 



-- Stored Procedure:
CREATE PROCEDURE Seasonal_DISCOUNT	(@Seasonal_Discount real )
AS
	Update dbo.RESERVATIONS 
	Set Total_Price=Total_Price-Total_Price *@Seasonal_Discount
	

EXECUTE dbo.Seasonal_Discount 0.1




-- Views For Buisness Report
CREATE VIEW Most_Rating_Hotels as 
SELECT  h.Name, AVG(R.Rating) AS Avg_Rating
FROM   dbo.HOTELS AS h INNER JOIN
             dbo.REVIEWS AS R ON h.Address_Street = R.Address_Street AND h.Address_Number = R.Address_Number AND h.Address_City = R.Address_City AND h.Address_Country = R.Address_Country
GROUP BY h.Name


CREATE VIEW Most_Profit_Hotels as 
SELECT  h.Name , SUM(r.Total_Price) AS Total_PROFIT
FROM   dbo.RESERVATIONS AS r INNER JOIN
             dbo.HOTELS AS h ON r.Ordered_In_Address_Street = h.Address_Street AND r.Ordered_In_Address_Number = h.Address_Number AND r.Ordered_In_Address_City = h.Address_City AND r.Ordered_In_Address_Country = h.Address_Country 
GROUP BY h.Name


CREATE VIEW Hotels_Facility_Profit as 
SELECT HF.Facility , Count(R.Reservation_ID) AS NUM_Of_Reservations
FROM HOTELS_FACILITIES AS HF JOIN HOTELS AS H ON HF.Address_City=H.Address_City AND HF.Address_Country=H.Address_Country AND HF.Address_Number=H.Address_Number AND HF.Address_Street=H.Address_Street AND HF.Name = H.Name JOIN RESERVATIONS AS R ON H.Address_City=R.Ordered_In_Address_City AND H.Address_Country=R.Ordered_In_Address_Country AND H.Address_Number=R.Ordered_In_Address_Number AND H.Address_Street=R.Ordered_In_Address_Street AND R.Ordered_In_Name=H.Name
GROUP BY HF.Facility


CREATE VIEW Most_Common_Num_OF_PPL as
SELECT TOP 50 s.Num_of_Adults , count(R.Reservation_ID) as Num_Of_Reservations
FROM SEARCHS AS S JOIN RESERVATIONS AS R ON S.IP_Address=R.Retrieved_Reservation_IP AND S.Search_DT=R.Retrieves_Reservation_DT join HOTELS as h on h.Address_City=r.Ordered_In_Address_City and h.Address_Country=r.Ordered_In_Address_Country and h.Name=r.Ordered_In_Name and h.Address_Number=r.Ordered_In_Address_Number and h.Address_Street=r.Ordered_In_Address_Street
Group by s.Num_of_Adults

CREATE VIEW Most_Sales_Per_Room_Type as
SELECT RO.Room_Type, RO.Address_Country, COUNT(*) AS NUMBER_OF_ROOMS_TYPE
FROM   dbo.ROOMS AS RO INNER JOIN
             dbo.RESERVATIONS AS R ON RO.Address_Street = R.Ordered_In_Address_Street AND RO.Address_Number = R.Ordered_In_Address_Number AND RO.Address_City = R.Ordered_In_Address_City AND RO.Address_Country = R.Ordered_In_Address_Country INNER JOIN
             dbo.CUSTOMERS AS C ON C.Email = R.Made_By
GROUP BY RO.Room_Type, RO.Address_Country



--View for Managers Report 
CREATE VIEW Most_Users_Countries as
SELECT TOP (10) C.Country, SUM(R.Total_Price) AS Money_Spent
FROM   dbo.CUSTOMERS AS C INNER JOIN
             dbo.RESERVATIONS AS R ON C.Email = R.Made_By
GROUP BY C.Country
ORDER BY Money_Spent DESC


CREATE VIEW Most_Profit_Country_Hotels as 
SELECT TOP 10  h.Address_Country , sum(R.Total_Price) AS Value_of_Money
FROM Hotels as h join RESERVATIONS as r on h.Address_City=r.Ordered_In_Address_City and h.Address_Number=r.Ordered_In_Address_Number and h.Address_Country=r.Ordered_In_Address_Country and h.Address_Street=r.Ordered_In_Address_Street and h.Name=r.Ordered_In_Name
Group by h.Address_Country
ORDER BY 2 DESC


CREATE VIEW Flights_To_Reservations as 
SELECT  COUNT(*) AS Num_Of_Flight_Reservation
FROM FLIGHTS AS F JOIN RETRIEVES_FLIGHTS AS RF ON F.Flight_Number = RF.Flight_Number JOIN SEARCHS AS S ON S.Search_DT=RF.Search_DT AND S.IP_Address=RF.IP_Address
WHERE RF.Proceed_To_External_Site = 1 

--	ONE POWER BI FUNCTION IN MANAGERS REPORT - REG CUSTOMERS FROM CUSTOMERS WAS BUILD WITHOUT VIEW TABLE FRMO SQL - STRAIGHT FROM POWER BI 


--COMPLEX STORED PROCEDURE : 

ALTER TABLE Customers
ADD Customer_Rank Varchar(50)




CREATE PROCEDURE sp_Customer_Rank
AS
		DECLARE @Email Varchar(40)
		DECLARE @Total_Price Int
		DECLARE @Customer_Rank Varchar (50)

		DECLARE   C1  CURSOR
		FOR	SELECT C.Email, SUM(r.Total_Price)
		FROM Customers as c join RESERVATIONS as r on r.Made_By=c.Email
		GROUP BY C.Email
	BEGIN
	OPEN    C1
FETCH  NEXT  FROM C1 
	INTO @Email, @Total_Price

WHILE (@@FETCH_STATUS = 0) 
	BEGIN
	IF (@Total_PRICE > 15000) SET @Customer_Rank = 'VIP'
			ELSE SET @Customer_Rank = 'Normal'
	UPDATE CUSTOMERS 
	SET  Customer_Rank = @Customer_Rank
	WHERE [Email] = @Email
	FETCH  NEXT  FROM C1 
	INTO @Email, @Total_Price
	END 
CLOSE 	C1
DEALLOCATE C1
End


EXECUTE sp_Customer_Rank


-- COMBINING OF COMPLEX  TOOLS : 

CREATE PROCEDURE  sp_Agoda_Points (@Email varchar(40) , @Agoda_Points int , @Reservation_ID integer ) 
AS
  if  @Agoda_Points < = ( Select  Agoda_Points
                     FROM REGISTERED_CUSTOMERS
					 Where Email=@Email) BEGIN 
											 select * from Before_Changes (@Email , @Reservation_ID) 
											 Execute sp_Agoda_Points_Customer @Email , @Agoda_Points
							                 EXECUTE sp_Agoda_Points_Reservation @Agoda_Points , @Reservation_ID
						                     select * from After_Changes (@Email , @Reservation_ID)
											 END 
											  
  ELSE 
  BEGIN
   PRINT 'You Dont have enough agoda points' 
   END




CREATE PROCEDURE sp_Agoda_Points_Customer (@Email varchar(40) , @Agoda_Points int ) 
AS
  UPDATE dbo.REGISTERED_CUSTOMERS
  Set Agoda_Points = Agoda_Points-@Agoda_Points
  WHERE Email=@Email

CREATE PROCEDURE sp_Agoda_Points_Reservation (@Agoda_Points int , @Reservation_ID int)
AS
  UPDATE dbo.RESERVATIONS
  SET Total_Price = Total_Price-@Agoda_Points
  Where Reservation_ID=@Reservation_ID


CREATE FUNCTION Before_Changes (@Email varchar(40) , @Reservation_ID INT)
RETURNS TABLE
AS
  RETURN 
  SELECT C.EMAIL ,RC.Agoda_Points,R.Total_Price 
  FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.EMAIL=R.MADE_BY JOIN REGISTERED_CUSTOMERS AS RC ON C.Email=RC.EMAIL
  WHERE C.Email = @Email  AND r.Reservation_ID=@Reservation_ID 


CREATE FUNCTION AFTER_Changes (@Email varchar(40) , @Reservation_ID INT)
RETURNS TABLE
AS
  RETURN 
  SELECT C.EMAIL ,RC.Agoda_Points,R.Total_Price 
  FROM CUSTOMERS AS C JOIN RESERVATIONS AS R ON C.EMAIL=R.MADE_BY JOIN REGISTERED_CUSTOMERS AS RC ON C.Email=RC.EMAIL
  WHERE C.Email = @Email  AND r.Reservation_ID=@Reservation_ID 


  EXECUTE sp_Agoda_Points 'tbordone4j@example.com' , 100 , 23

  
  -- report based on complex query : 

CREATE VIEW COUNT_RATING1 AS 
SELECT H.Name, h.Address_Country, B.Average_Country_Rating , COUNT(R.DT) AS NUM_OF_RATINGS , AVG(R.Rating) as Average_Rating  
FROM HOTELS AS H JOIN REVIEWS AS R ON H.Name=R.Name AND H.Address_City=R.Address_City AND H.Address_Country=R.Address_Country AND H.Address_Number=R.Address_Number AND H.Address_Street=R.Address_Street
join (SELECT Address_Country , AVG(RATING) as Average_Country_Rating
	  FROM REVIEWS
      group by Address_Country ) as b on b.Address_Country=h.Address_Country
GROUP BY H.Name, h.Address_Country , B.Average_Country_Rating



CREATE VIEW COUNT_OF_RES_PER_HOTEL1 AS 
SELECT H.Name , h.Address_Country,b.Total_Profit_Of_Country, SUM(R.Total_Price) AS Total_Profit , COUNT(R.Reservation_ID) AS NUM_OF_RESERVATIONS  
FROM RESERVATIONS AS R JOIN HOTELS AS H ON R.Ordered_In_Name=H.Name AND R.Ordered_In_Address_City=H.Address_City AND H.Address_Country=R.Ordered_In_Address_Country AND H.Address_Number = R.Ordered_In_Address_Number AND H.Address_Street=R.Ordered_In_Address_Street
join ( SELECT Ordered_In_Address_Country , SUM(Total_Price) as Total_Profit_Of_Country
FROM RESERVATIONS
GROUP BY Ordered_In_Address_Country) as b on b.Ordered_In_Address_Country = h.Address_Country
GROUP BY H.NAME, h.Address_Country, b.Total_Profit_Of_Country



 SELECT   h.Name,H.Address_Street , H.Address_Number , H.Address_City, H.Address_Country , B.Total_Profit,b.Total_Profit_Of_Country, cast(b.Total_Profit as real)/cast(b.Total_Profit_Of_Country as real) *100 as Precentage_Of_Hotel_Porfit_From_Country_Profit ,B.NUM_OF_RESERVATIONS , A.NUM_OF_RATINGS , A.Average_Rating , A.Average_Country_Rating
 FROM HOTELS AS H  JOIN COUNT_RATING1 AS A ON H.Name=A.Name JOIN COUNT_OF_RES_PER_HOTEL1 AS B ON H.Name =B.Name 
 ORDER BY B.Total_Profit DESC




