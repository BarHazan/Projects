#Comparison 1 - Current State vs SUB 1

test_1_measure1<- t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Current_State,y=lab_Center_mean_Flowtime_vector_per_repeat_Sub1,
                         alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_1_measure1 

test_1_measure2<-t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Current_State,y=Urgent_North_Mean_Queue_Vector_per_repeat_Sub1,
                        alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_1_measure2

test_1_measure3 <-t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Current_State,y=Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub1,
                         alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_1_measure3

#Comparison 2 - Current State vs SUB 2:

test_2_measure1 <-  t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Current_State,y=lab_Center_mean_Flowtime_vector_per_repeat_Sub2,
                           alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_2_measure1

test_2_measure2 <-  t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Current_State,y=Urgent_North_Mean_Queue_Vector_per_repeat_Sub2,
                           alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_2_measure2

test_2_measure3 <- t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Current_State,y=Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub2,
                          alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_2_measure3

#Comparison 3: - Sub1 vs Sub2:

test_3_measure1 <-  t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Sub1,y=lab_Center_mean_Flowtime_vector_per_repeat_Sub2,
                           alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_3_measure1

test_3_measure2 <-  t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Sub1,y=Urgent_North_Mean_Queue_Vector_per_repeat_Sub2,
                           alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_3_measure2

test_3_measure3 <- t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub1,y=Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub2,
                          alternative="two.sided",paired=TRUE,var.equal=TRUE,conf.level=0.99)
test_3_measure3



