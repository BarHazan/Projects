


##----------------------------------------- 1.  all functions ------------------------------------------------
addService<-	function  (trajectory, sname, timeDist){
  updatedPath <- seize(trajectory, sname)%>%
    timeout(timeDist)%>%
    release( sname)
  return(updatedPath)
}

addServiceSelected <- function(trajectory, idNum, timeDist){
  updatedPath <- seize_selected(trajectory, id = idNum)%>%
    timeout(timeDist)%>%
    release_selected (id= idNum)
  return(updatedPath)
}

itsPositive <- function() {
  inconclusiveTest <- get_attribute(COVID19_SIMULATION,"inconclusive_tests")
  if (inconclusiveTest == 2) {
    return (FALSE)
  }
  return (TRUE)
}

reduceNoise <- function(vec ,m , i , w) {
  Y <- 0
  if (i == 1) {
    return (vec[i])
  }
  else if (i > 1 && i <= w) {
    for(s in (1-i) : (i-1)){
      Y <- Y + vec[i+s]
    }
    Y <- Y/(2*i-1)
  }
  else if (i >= w+1 && i <= m-w) {
    for(s in -w : w){
      Y <- Y + vec[i+s]
    }
    Y <- Y/(2*w+1)
  }
  return(Y)
}

##----------------------------------------- 2.  all simulation parameters ------------------------------------------------
days <- 2
repeats <- 1
simulationTime <- 24*days*60
change_capacity_mini_driveIn <-schedule(c(0,12*60),c(3,2),24*60)
change_capacity_door_driveIn <-schedule(c(0,15*60),c(Inf,0),24*60)
change_capacity_door_urgent <-schedule(c(3*60,7*60,8*60,12*60),c(Inf,0,Inf,0),24*60)


##----------------------------------------- 3.  Init Simulation and add all resources  ------------------------------------------------

COVID19_SIMULATION<- simmer("COVID19_SIMULATION")%>%
  
  ####drive in doors
  add_resource("door_driveIn_north",change_capacity_door_driveIn,queue_size = 0)%>%
  add_resource("door_driveIn_center",change_capacity_door_driveIn,queue_size = 0)%>%
  add_resource("door_driveIn_south",change_capacity_door_driveIn,queue_size = 0)%>%
  
  ####urgent doors
  add_resource("door_urgent_north",change_capacity_door_urgent,queue_size = 0)%>%
  add_resource("door_urgent_center",change_capacity_door_urgent,queue_size = 0)%>%
  add_resource("door_urgent_south",change_capacity_door_urgent,queue_size = 0)%>%
  
  ####mini drive in
  add_resource("mini_driveIn_north_1",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_north_2",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_north_3",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_center_1",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_center_2",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_center_3",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_center_4",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_south_1",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_south_2",change_capacity_mini_driveIn,queue_size=Inf)%>%
  add_resource("mini_driveIn_south_3",change_capacity_mini_driveIn,queue_size=Inf)%>%
  
  ####ambulances
  add_resource("ambulance1",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance2",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance3",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance4",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance5",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance6",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance7",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance8",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance9",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance10",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance11",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance12",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance13",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance14",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance15",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance16",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance17",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance18",capacity=1,queue_size=Inf)%>% 
  add_resource("ambulance19",capacity=1,queue_size=Inf)%>%
  add_resource("ambulance20",capacity=1,queue_size=Inf)%>% 
  
  ####urgents
  add_resource("urgent_north_1",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_north_2",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_north_3",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_north_4",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_north_5",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_1",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_2",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_3",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_4",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_5",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_6",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_center_7",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_south_1",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_south_2",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_south_3",capacity=1,queue_size=Inf)%>%
  add_resource("urgent_south_4",capacity=1,queue_size=Inf)%>%
  
  ####labs
  add_resource("lab_north",capacity=20,queue_size=Inf)%>%
  add_resource("lab_center",capacity=21,queue_size=Inf)%>%
  add_resource("lab_south",capacity=20,queue_size=Inf)

##----------------------------------------- 4.  All trajectories, start from main trajectory and add sub-trajectories ABOVE IT it . ------------------------------------------------

##End Trajectories :
positive_home<- trajectory("positive_home")%>%
  set_attribute(keys="test_result",value=1)%>% ## 1-positive , 2-negative
  activate("isolation_people") #activate 2 entities from isolation

negetive_home<- trajectory("negetive_home")%>%
  set_attribute(keys="test_result",value=2) ## 1-positive , 2-negative

#### DRIVE IN 
##second test
second_test_drivein_traj <- trajectory("second_test_drivein_traj")%>%
  set_attribute(keys="inconclusive_tests",value=1, mod= "+" , init = 0)%>% ## 1-1 2-2
  simmer::rollback(amount = 14 , check = function () itsPositive())%>% # If its the second time that arrive here - go positive_home
  join(positive_home)

##wait for morning tests
waitForMorning_driveIn_traj <- trajectory("waitForMorning_driveIn_traj")%>%
  trap(signals = "goodMorningDriveIn")%>%
  wait()%>%
  simmer::rollback(amount = 3)

driveIn_doorMan_traj <- trajectory("driveIn_doorMan_traj")%>%
  send("goodMorningDriveIn")

##Labs :
#North :
lab_north_drivein_traj <- trajectory("lab_north_drivein_traj")%>%
  simmer::separate()%>%
  addService("lab_north",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_drivein_traj,negetive_home)

#center
lab_center_drivein_traj <- trajectory("lab_center_drivein_traj")%>%
  simmer::separate()%>%
  addService("lab_center",5)%>% 
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_drivein_traj,negetive_home)

#South
lab_south_drivein_traj <- trajectory("lab_south_drivein_traj")%>%
  simmer::separate()%>% 
  addService("lab_south",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_drivein_traj,negetive_home)

##Cooling Box Trajectories  :
#North: 
north_cooling_box_Traj <- trajectory("north_cooling_box_Traj")%>%
  batch(100, timeout = 4*60)%>% #wait for 100 tests or 4 hours to continue
  timeout(function ()rnorm(1,15,5))%>%
  join (lab_north_drivein_traj)

#Center:
center_cooling_box_Traj<- trajectory("center_cooling_box_Traj")%>%
  batch(100, timeout = 4*60 )%>% #wait for 100 tests or 4 hours to continue
  timeout(function () rnorm(1,15,5))%>%
  join (lab_center_drivein_traj)

#South:
south_cooling_box_Traj<- trajectory("south_cooling_box_Traj")%>%
  batch(100, timeout = 4*60)%>% #wait for 100 tests or 4 hours to continue
  timeout(function () rnorm(1,15,5))%>%
  join (lab_south_drivein_traj)

##Mega Drive In:
driveIn_north_Traj<-trajectory("driveIn_north_Traj")%>%
  set_attribute(keys="area",value=1)%>% # 1-north, 2-center, 3-south
  seize("door_driveIn_north",continue = T, reject = waitForMorning_driveIn_traj)%>%
  release("door_driveIn_north")%>%
  simmer::select(resources = c("mini_driveIn_north_1", "mini_driveIn_north_2", "mini_driveIn_north_3"),policy = c("shortest-queue-available"),id = 0)%>%
  addServiceSelected(0, 1.5)%>%
  join(north_cooling_box_Traj)

driveIn_center_Traj<-trajectory("driveIn_center_Traj")%>%
  set_attribute(keys="area",value=2)%>% # 1-north, 2-center, 3-south
  seize("door_driveIn_center",continue = T, reject = waitForMorning_driveIn_traj)%>%
  release("door_driveIn_center")%>%
  simmer::select(resources = c("mini_driveIn_center_1", "mini_driveIn_center_2", "mini_driveIn_center_3","mini_driveIn_center_4" ),policy = c("shortest-queue-available"),id = 1)%>%
  addServiceSelected(1, 1.5)%>%
  join(center_cooling_box_Traj)

driveIn_south_Traj<-trajectory("driveIn_south_Traj")%>%
  set_attribute(keys="area",value=3)%>% # 1-north, 2-center, 3-south
  seize("door_driveIn_south",continue = T, reject = waitForMorning_driveIn_traj)%>%
  release("door_driveIn_south")%>%
  simmer::select(resources = c("mini_driveIn_south_1", "mini_driveIn_south_2", "mini_driveIn_south_3"),policy = c("shortest-queue-available"),id = 2)%>%
  addServiceSelected(2, 1.5)%>%
  join(south_cooling_box_Traj)

##Country Drive In :
driveIn_traj<-trajectory("driveIn_traj")%>%
  set_attribute(keys="type",value=1)%>% # 1-drive in, 2-symptoms, 3-urgent
  branch (option = function() rdiscrete(1,c(0.35,0.42,0.23),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),driveIn_north_Traj,driveIn_center_Traj,driveIn_south_Traj)

#############################################################################

####Symptoms(Ambulances):
##second test
second_test_symptoms_traj <- trajectory("second_test_symptoms_traj")%>%
  set_attribute(keys="inconclusive_tests",value=1, mod= "+" , init = 0)%>%
  simmer::rollback(amount = 17 , check = function () itsPositive())%>% # If its the second time that arrive here - go positive_home
  join(positive_home)

##labs
lab_ambulance_north_traj <- trajectory("lab_ambulance_north_traj")%>%
  simmer::separate()%>%
  addService("lab_north",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_symptoms_traj,negetive_home)

lab_ambulance_center_traj <- trajectory("lab_ambulance_center_traj")%>%
  simmer::separate()%>%
  addService("lab_center",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_symptoms_traj,negetive_home)

lab_ambulance_south_traj <- trajectory("lab_ambulance_south_traj")%>%
  simmer::separate()%>%
  addService("lab_south",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_symptoms_traj,negetive_home)

##ambulances service
ambulance1_traj <- trajectory("ambulance1_traj")%>%  
  seize("ambulance1")%>%
  timeout (function () rtriangle(1,10,20,15))%>% #drive to customer
  timeout(1.5)%>% #test time
  release("ambulance1")%>% 
  batch(Inf , 4*60 )%>% #wait 4 hours to continue with all tests
  set_capacity("ambulance1",0)%>% #need to drive to lab, can't let service
  timeout(function ()rnorm(1,15,5))%>% # drive to lab
  timeout(10)%>% #unload the tests
  activate("ambulance_refill1")%>% #go get new equipment
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)
#^decide which lab the ambulance go with the batch  

ambulance2_traj <- trajectory("ambulance2_traj")%>%  
  seize("ambulance2")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance2")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance2",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill2")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance3_traj <- trajectory("ambulance3_traj")%>%  
  seize("ambulance3")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance3")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance3",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill3")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance4_traj <- trajectory("ambulance4_traj")%>%  
  seize("ambulance4")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance4")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance4",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill4")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance5_traj <- trajectory("ambulance5_traj")%>%  
  seize("ambulance5")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance5")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance5",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>% 
  activate("ambulance_refill5")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance6_traj <- trajectory("ambulance6_traj")%>%  
  seize("ambulance6")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance6")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance6",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill6")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance7_traj <- trajectory("ambulance7_traj")%>%  
  seize("ambulance7")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance7")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance7",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill7")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance8_traj <- trajectory("ambulance8_traj")%>%  
  seize("ambulance8")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance8")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance8",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill8")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance9_traj <- trajectory("ambulance9_traj")%>%  
  seize("ambulance9")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance9")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance9",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill9")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance10_traj <- trajectory("ambulance10_traj")%>%  
  seize("ambulance10")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance10")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance10",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill10")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance11_traj <- trajectory("ambulance11_traj")%>%  
  seize("ambulance11")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance11")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance11",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill11")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance12_traj <- trajectory("ambulance12_traj")%>%  
  seize("ambulance12")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance12")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance12",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill12")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance13_traj <- trajectory("ambulance13_traj")%>%  
  seize("ambulance13")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance13")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance13",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>% 
  activate("ambulance_refill13")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance14_traj <- trajectory("ambulance14_traj")%>%  
  seize("ambulance14")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance14")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance14",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill14")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance15_traj <- trajectory("ambulance15_traj")%>%  
  seize("ambulance15")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance15")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance15",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill15")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance16_traj <- trajectory("ambulance16_traj")%>%  
  seize("ambulance16")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance16")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance16",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill16")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance17_traj <- trajectory("ambulance17_traj")%>%  
  seize("ambulance17")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance17")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance17",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill17")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance18_traj <- trajectory("ambulance18_traj")%>%  
  seize("ambulance18")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance18")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance18",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill18")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance19_traj <- trajectory("ambulance19_traj")%>%  
  seize("ambulance19")%>%
  timeout (function () rtriangle(1,10,20,15))%>%
  timeout(1.5)%>%
  release("ambulance19")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance19",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill19")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

ambulance20_traj <- trajectory("ambulance20_traj")%>%  
  seize("ambulance20")%>% 
  timeout (function () rtriangle(1,10,20,15))%>% 
  timeout(1.5)%>%
  release("ambulance20")%>%
  batch(Inf , 4*60 )%>%
  set_capacity("ambulance20",0)%>%
  timeout(function ()rnorm(1,15,5))%>%
  timeout(10)%>%
  activate("ambulance_refill20")%>%
  branch (option = function() rdiscrete(1,c(1/3,1/3,1/3),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),lab_ambulance_north_traj,lab_ambulance_center_traj,lab_ambulance_south_traj)

symptoms_traj<-trajectory("symptoms_traj")%>%
  set_attribute(keys="type",value=2)%>% # 1-drive in, 2-symptoms, 3-urgent
  branch (option = function() rdiscrete(1,c(1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20,1/20)
                                        ,c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20))
          ,continue = c(FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE)
          ,ambulance1_traj,ambulance2_traj,ambulance3_traj,ambulance4_traj,ambulance5_traj,ambulance6_traj,ambulance7_traj,ambulance8_traj,ambulance9_traj
          ,ambulance10_traj,ambulance11_traj,ambulance12_traj,ambulance13_traj,ambulance14_traj,ambulance15_traj,ambulance16_traj,ambulance17_traj,ambulance18_traj,ambulance19_traj,ambulance20_traj)

##ambulances refill new equipment
ambulance_refill1 <- trajectory("ambulance_refill1")%>%
  timeout(10)%>% #refill time
  set_capacity("ambulance1",1)

ambulance_refill2 <- trajectory("ambulance_refill2")%>%
  timeout(10)%>%
  set_capacity("ambulance2",1)

ambulance_refill3 <- trajectory("ambulance_refill3")%>%
  timeout(10)%>%
  set_capacity("ambulance3",1)

ambulance_refill4 <- trajectory("ambulance_refill4")%>%
  timeout(10)%>%
  set_capacity("ambulance4",1)

ambulance_refill5 <- trajectory("ambulance_refill5")%>%
  timeout(10)%>%
  set_capacity("ambulance5",1)

ambulance_refill6 <- trajectory("ambulance_refill6")%>%
  timeout(10)%>%
  set_capacity("ambulance6",1)

ambulance_refill7 <- trajectory("ambulance_refill7")%>%
  timeout(10)%>%
  set_capacity("ambulance7",1)

ambulance_refill8 <- trajectory("ambulance_refill8")%>%
  timeout(10)%>%
  set_capacity("ambulance8",1)

ambulance_refill9 <- trajectory("ambulance_refill9")%>%
  timeout(10)%>%
  set_capacity("ambulance9",1)

ambulance_refill10 <- trajectory("ambulance_refill10")%>%
  timeout(10)%>%
  set_capacity("ambulance10",1)

ambulance_refill11 <- trajectory("ambulance_refill11")%>%
  timeout(10)%>%
  set_capacity("ambulance11",1)

ambulance_refill12 <- trajectory("ambulance_refill12")%>%
  timeout(10)%>%
  set_capacity("ambulance12",1)

ambulance_refill13 <- trajectory("ambulance_refill13")%>%
  timeout(10)%>%
  set_capacity("ambulance13",1)

ambulance_refill14 <- trajectory("ambulance_refill14")%>%
  timeout(10)%>%
  set_capacity("ambulance14",1)

ambulance_refill15<- trajectory("ambulance_refill15")%>%
  timeout(10)%>%
  set_capacity("ambulance15",1)

ambulance_refill16 <- trajectory("ambulance_refill16")%>%
  timeout(10)%>%
  set_capacity("ambulance16",1)

ambulance_refill17 <- trajectory("ambulance_refill17")%>%
  timeout(10)%>%
  set_capacity("ambulance17",1)

ambulance_refill18 <- trajectory("ambulance_refill18")%>%
  timeout(10)%>%
  set_capacity("ambulance18",1)

ambulance_refill19 <- trajectory("ambulance_refill19")%>%
  timeout(10)%>%
  set_capacity("ambulance19",1)

ambulance_refill20 <- trajectory("ambulance_refill20")%>%
  timeout(10)%>%
  set_capacity("ambulance20",1)

#############################################################################

####Urgent :
##second test
second_test_urgent_traj <- trajectory("second_test_urgent_traj")%>%
  set_attribute(keys="inconclusive_tests",value=1, mod= "+" , init = 0)%>%
  simmer::rollback(amount =11 , check = function () itsPositive())%>% # If its the second time that arrive here - go positive_home
  join(positive_home)

##wait for open hours tests
waitForMorning_urgent_traj <- trajectory("waitForMorning_urgent_traj")%>%
  trap(signals = "goodMorningUrgent")%>%
  wait()%>%
  simmer::rollback(amount = 3)

urgent_doorMan_traj <- trajectory("urgent_doorMan_traj")%>%
  send("goodMorningUrgent")

##Labs :
#North :
lab_north_urgent_traj <- trajectory("lab_north_urgent_traj")%>%
  addService("lab_north",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_urgent_traj,negetive_home)

#center
lab_center_urgent_traj <- trajectory("lab_center_urgent_traj")%>%
  addService("lab_center",5)%>% 
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_urgent_traj,negetive_home)

#South
lab_south_urgent_traj <- trajectory("lab_south_urgent_traj")%>%
  addService("lab_south",5)%>%
  branch (option = function() rdiscrete(1,c(0.1,0.15,0.75),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),positive_home,second_test_urgent_traj,negetive_home)

##Hospitals per region (urgent)
urgent_north_Traj<-trajectory("urgent_north_Traj")%>%
  set_attribute(keys="area",value=1)%>% # 1-north, 2-center, 3-south
  seize("door_urgent_north",continue = T, reject = waitForMorning_urgent_traj)%>%
  release("door_urgent_north")%>%
  simmer::select(resources = c("urgent_north_1","urgent_north_2","urgent_north_3","urgent_north_4", "urgent_north_5"),policy = c("random"),id = 4)%>%
  addServiceSelected(4, 1.5)%>%
  join (lab_north_urgent_traj)

urgent_center_Traj<-trajectory("urgent_center_Traj")%>%
  set_attribute(keys="area",value=2)%>% # 1-north, 2-center, 3-south
  seize("door_urgent_center",continue = T, reject = waitForMorning_urgent_traj)%>%
  release("door_urgent_center")%>%
  simmer::select(resources = c("urgent_center_1","urgent_center_2","urgent_center_3","urgent_center_4","urgent_center_5","urgent_center_6","urgent_center_7"),policy = c("random"),id = 5)%>%
  addServiceSelected(5, 1.5)%>%
  join (lab_center_urgent_traj)

urgent_south_Traj<-trajectory("urgent_south_Traj")%>%
  set_attribute(keys="area",value=3)%>% # 1-north, 2-center, 3-south
  seize("door_urgent_south",continue = T, reject = waitForMorning_urgent_traj)%>%
  release("door_urgent_south")%>%
  simmer::select(resources = c("urgent_south_1","urgent_south_2","urgent_south_3","urgent_south_4"),policy = c("random"),id = 6)%>%
  addServiceSelected(6, 1.5)%>%
  join (lab_south_urgent_traj)

##Country Urgent :
urgent_traj<-trajectory("urgent_traj")%>%
  set_attribute(keys="type",value=3)%>% # 1-drive in, 2-symptoms, 3-urgent
  branch (option = function() rdiscrete(1,c(0.35,0.42,0.23),c(1,2,3)), continue = c(FALSE,FALSE,FALSE),urgent_north_Traj,urgent_center_Traj,urgent_south_Traj)

##----------------------------------------- 5.  All Generators, ALWAYS LAST. ------------------------------------------------


COVID19_SIMULATION%>%
  
  ##drive in
  add_generator("driveIn_people", driveIn_traj, from_to(0,15*60,dist = function () rexp(1,0.625),arrive = TRUE,every =24*60), mon=2)%>%
  add_generator("isolation_people", driveIn_traj, when_activated(2), mon=2)%>%
  add_generator("driveIn_doorMan", driveIn_doorMan_traj, from_to(24*60,simulationTime ,function() 24*60,arrive = TRUE, every = 24*60), mon=2)%>%
  
  ##symptoms
  add_generator("symptoms_people", symptoms_traj, distribution = function () rexp(1,0.5000868), mon=2)%>%
  add_generator("ambulance_refill1", ambulance_refill1, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill2", ambulance_refill2, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill3", ambulance_refill3, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill4", ambulance_refill4, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill5", ambulance_refill5, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill6", ambulance_refill6, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill7", ambulance_refill7, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill8", ambulance_refill8, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill9", ambulance_refill9, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill10", ambulance_refill10, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill11", ambulance_refill11, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill12", ambulance_refill12, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill13", ambulance_refill13, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill14", ambulance_refill14, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill15", ambulance_refill15, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill16", ambulance_refill16, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill17", ambulance_refill17, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill18", ambulance_refill18, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill19", ambulance_refill19, when_activated(1), mon=2,priority=1)%>%
  add_generator("ambulance_refill20", ambulance_refill20, when_activated(1), mon=2,priority=1)%>%
  
  ##urgent
  add_generator("urgent_people_morning", urgent_traj,from_to(3*60,7*60,dist = function () rexp(1,8),TRUE,24*60) , mon=2,priority=1)%>% 
  add_generator("urgent_people_noon", urgent_traj,from_to(8*60,12*60,dist = function () rexp(1,8),TRUE,24*60) , mon=2,priority=1)%>%
  add_generator("urgent_doorMan_morning", urgent_doorMan_traj, from_to(27*60,simulationTime ,function()24*60,arrive = TRUE, every = 24*60), mon=2)%>%
  add_generator("urgent_doorMan_noon", urgent_doorMan_traj,from_to(8*60,simulationTime ,function()24*60,arrive = TRUE, every = 24*60), mon=2)


##----------------------------------------- 6.  reset, run, plots, outputs ------------------------------------------------
models_list <- mclapply(1:repeats , function(i){
  set.seed(((i+100)^2)*3-7)
  reset(COVID19_SIMULATION)%>%run(until=simulationTime)%>%wrap()
})