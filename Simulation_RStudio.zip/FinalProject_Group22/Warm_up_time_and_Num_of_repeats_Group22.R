
welch_w <- 10
time <- seq(1,(days - 2*welch_w),1)

## Preparing the Data By Days:
lab_center_mean_Flowtime_Matrix <- matrix(data=NA,nrow=repeats,ncol=days)
Urgent_north_mean_Queue_Matrix <- matrix(data=NA,nrow=repeats,ncol=days)
avg_ambulacne_waiting_matrix <- matrix(data=NA,nrow=repeats,ncol=days)

for (i in 1:repeats){ ## Number OF Repeats
  # Measurement 1:
  arrivalDataPerResource <- get_mon_arrivals(models_list[[i]] , per_resource = T)
  arrivalDataPerResource_lab <- subset(arrivalDataPerResource, arrivalDataPerResource$resource=="lab_center")
  arrivalDataPerResource_lab$flow_time <- arrivalDataPerResource_lab$end_time-arrivalDataPerResource_lab$start_time
  # Measurement2:
  resourceData <- get_mon_resources(models_list[[i]])
  Urgent_Queue_Data <- subset(resourceData, resourceData$resource=="urgent_north_1"|
                                resourceData$resource=="urgent_north_2"|
                                resourceData$resource=="urgent_north_3")
  # Measurement3:
  arrivalDataPerResource_Symptoms <-    sqldf ("select *                      
                                       from arrivalDataPerResource 
                                       where (name LIKE 'symptoms_%') AND (resource LIKE 'ambulance%')
                                      ")
  arrivalDataPerResource_Symptoms$waiting_time <- arrivalDataPerResource_Symptoms$end_time-
                                                  (arrivalDataPerResource_Symptoms$start_time+
                                                   arrivalDataPerResource_Symptoms$activity_time)
  for(j in 1:days){ ## Number OF DAy
    # Measurement1:
    daily_arrivalDataPerResource_lab <- subset(arrivalDataPerResource_lab ,( arrivalDataPerResource_lab$start_time>=24*60*(j-1)&
                                                                               arrivalDataPerResource_lab$start_time<(24*60*j)))
    daily_temp_flow_time <- mean(daily_arrivalDataPerResource_lab$flow_time)
    lab_center_mean_Flowtime_Matrix[i,j] <- daily_temp_flow_time
    
    # Measurement2:
    daily_urgent_data <- subset(Urgent_Queue_Data ,( Urgent_Queue_Data$time>=24*60*(j-1)&
                                                       Urgent_Queue_Data$time<(24*60*j)))
    daily_mean_queue_size <- mean(daily_urgent_data$queue)
    Urgent_north_mean_Queue_Matrix[i,j] <- daily_mean_queue_size
    
    # Measurement3:
    daily_avg_ambulance_waiting_data <- subset(arrivalDataPerResource_Symptoms ,(arrivalDataPerResource_Symptoms$start_time>=24*60*(j-1)&
                                                                                   arrivalDataPerResource_Symptoms$start_time<(24*60*j)))
    daily_avg_ambulance_waiting_mean <- mean(daily_avg_ambulance_waiting_data$waiting_time)
    avg_ambulacne_waiting_matrix[i,j] <- daily_avg_ambulance_waiting_mean
    
  }
}

## Welching :
# Measurement1:
Welch_lab_center_mean_Flowtime_Vector <- vector() 
for ( i in 1:days){
  Welch_lab_center_mean_Flowtime_Vector[i] <- mean(lab_center_mean_Flowtime_Matrix[,i])
}

Welch_lab_center_mean_Flowtime_Smooth_Vector <- vector()
for ( i in 1:(days - welch_w)){
  Welch_lab_center_mean_Flowtime_Smooth_Vector[i] <- reduceNoise (Welch_lab_center_mean_Flowtime_Vector,
                                                                  m=days,  i=i ,w=welch_w)
}

Welch_lab_center_mean_Flowtime_extraSmooth_Vector <- vector()
for ( i in 1:(days - 2*welch_w)){
  Welch_lab_center_mean_Flowtime_extraSmooth_Vector[i] <- reduceNoise (Welch_lab_center_mean_Flowtime_Smooth_Vector,
                                                                       m=(days - welch_w),  i=i ,w=welch_w)
}

ggplot(data=NULL , mapping = aes(x=time , y = Welch_lab_center_mean_Flowtime_extraSmooth_Vector))+geom_line()+
  xlab("simulation_time")+ylab("center_lab_flowtime_mean")+ggtitle("center_labs_flowtime for warmup time")


# Measurement2 - Urgent North avg queue
Welch_Urgent_north_mean_Queue_Vector <- vector() 
for ( i in 1:days){
  Welch_Urgent_north_mean_Queue_Vector[i] <- mean(Urgent_north_mean_Queue_Matrix[,i])
}

Welch_Urgent_north_mean_Queue_Smooth_Vector <- vector()
for ( i in 1:(days-welch_w)){
  Welch_Urgent_north_mean_Queue_Smooth_Vector[i] <- reduceNoise(Welch_Urgent_north_mean_Queue_Vector,
                                                                m=days , i=i , w=welch_w)
}

Welch_Urgent_north_mean_Queue_extraSmooth_Vector <- vector()
for ( i in 1:(days-2*welch_w)){
  Welch_Urgent_north_mean_Queue_extraSmooth_Vector[i] <- reduceNoise (Welch_Urgent_north_mean_Queue_Smooth_Vector,
                                                                      m=(days-welch_w),  i=i ,w=welch_w)
}

ggplot(data=NULL , mapping = aes(x=time , y = Welch_Urgent_north_mean_Queue_extraSmooth_Vector))+geom_line()+
  xlab("simulation_time")+ylab("urgent_north_mean_queue")+ggtitle("urgent_north_mean_queue for warmup time")


# Measurement 3: AVG waiting time Ambulance
Welch_avg_ambulacne_waiting_Vector <- vector() 
for ( i in 1:days){
  Welch_avg_ambulacne_waiting_Vector[i] <- mean(avg_ambulacne_waiting_matrix[,i])
}

Welch_avg_ambulance_waiting_Smooth_Vector <- vector()
for ( i in 1:(days-welch_w)){
  Welch_avg_ambulance_waiting_Smooth_Vector[i] <- reduceNoise (Welch_avg_ambulacne_waiting_Vector,
                                                               m=days,  i=i ,w=welch_w)
}

Welch_avg_ambulance_waiting_extraSmooth_Vector <- vector()
for ( i in 1:(days-2*welch_w)){
  Welch_avg_ambulance_waiting_extraSmooth_Vector[i] <- reduceNoise (Welch_avg_ambulance_waiting_Smooth_Vector,
                                                                    m=(days-welch_w),  i=i ,w=welch_w)
}

ggplot(data=NULL , mapping = aes(x=time , y = Welch_avg_ambulance_waiting_extraSmooth_Vector))+geom_line()+
  xlab("simulation_time")+ylab("Avg_Ambulance_Waiting_Time")+ggtitle("Avg_Ambulance_Waiting_Time for warmup time")


warmup_time <- 20
## Deciding the Num of repeats - Current State:
#Measurement1 :
lab_Center_mean_Flowtime_data_without_warmUpTime <- lab_center_mean_Flowtime_Matrix[,(warmup_time+1):days] # delete data from warm up time
lab_Center_mean_Flowtime_vector_per_repeat_Current_State <- apply(lab_Center_mean_Flowtime_data_without_warmUpTime,2,mean) # avg of all days in which repeat
test_mean_flowtime <- t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Current_State,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_flowtime<-(test_mean_flowtime$conf.int[2]-test_mean_flowtime$conf.int[1])/2
meanFlow <- test_mean_flowtime$estimate
Relative_accuracy_flowtime <-half_ci_flowtime/meanFlow
half_ci_flowtime #Revah Semah
meanFlow ##Mean
Relative_accuracy_flowtime ##Lamda

#Measurement2 :
Urgent_North_Mean_Queue_data_without_warmUpTime <- Urgent_north_mean_Queue_Matrix[,(warmup_time+1):days]
Urgent_North_Mean_Queue_Vector_per_repeat_Current_State <- apply(Urgent_North_Mean_Queue_data_without_warmUpTime,2,mean)
test_mean_queue <- t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Current_State,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_mean_queue <- (test_mean_queue$conf.int[2]-test_mean_queue$conf.int[1])/2 
meanQueue <- test_mean_queue$estimate
Relative_accuracy_meanqueue <-half_ci_mean_queue/meanQueue
half_ci_mean_queue
meanQueue
Relative_accuracy_meanqueue

#Measurement3:
Ambulance_Avg_Waitingtime_Data_without_warmUpTime <- avg_ambulacne_waiting_matrix[,(warmup_time+1):days]
Ambulance_Avg_Waitingtime_Vector_Per_repeat_Current_State <- apply(Ambulance_Avg_Waitingtime_Data_without_warmUpTime,2,mean)
test_waitingTime <- t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Current_State,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_waitingTime <- (test_waitingTime$conf.int[2]-test_waitingTime$conf.int[1])/2 
meanWaitingTime <- test_waitingTime$estimate
Relative_accuracy_meanWaitingTime <-half_ci_waitingTime/meanWaitingTime
half_ci_waitingTime
meanWaitingTime
Relative_accuracy_meanWaitingTime


## Deciding the Num of repeats - Sub 1:
#Measurement1 :
lab_Center_mean_Flowtime_data_without_warmUpTime <- lab_center_mean_Flowtime_Matrix[,(warmup_time+1):days] # delete data from warm up time
lab_Center_mean_Flowtime_vector_per_repeat_Sub1 <- apply(lab_Center_mean_Flowtime_data_without_warmUpTime,2,mean) # avg of all days in which repeat
test_mean_flowtime <- t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Sub1,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_flowtime<-(test_mean_flowtime$conf.int[2]-test_mean_flowtime$conf.int[1])/2
meanFlow <- test_mean_flowtime$estimate
Relative_accuracy_flowtime <-half_ci_flowtime/meanFlow
half_ci_flowtime
meanFlow
Relative_accuracy_flowtime

#Measurement2 :
Urgent_North_Mean_Queue_data_without_warmUpTime <- Urgent_north_mean_Queue_Matrix[,(warmup_time+1):days]
Urgent_North_Mean_Queue_Vector_per_repeat_Sub1 <- apply(Urgent_North_Mean_Queue_data_without_warmUpTime,2,mean)
test_mean_queue <- t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Sub1,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_mean_queue <- (test_mean_queue$conf.int[2]-test_mean_queue$conf.int[1])/2 
meanQueue <- test_mean_queue$estimate
Relative_accuracy_meanqueue <-half_ci_mean_queue/meanQueue
half_ci_mean_queue
meanQueue
Relative_accuracy_meanqueue

#Measurement3:
Ambulance_Avg_Waitingtime_Data_without_warmUpTime <- avg_ambulacne_waiting_matrix[,(warmup_time+1):days]
Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub1 <- apply(Ambulance_Avg_Waitingtime_Data_without_warmUpTime,2,mean)
test_waitingTime <- t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub1,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_waitingTime <- (test_waitingTime$conf.int[2]-test_waitingTime$conf.int[1])/2 
meanWaitingTime <- test_waitingTime$estimate
Relative_accuracy_meanWaitingTime <-half_ci_waitingTime/meanWaitingTime
half_ci_waitingTime
meanWaitingTime
Relative_accuracy_meanWaitingTime


## Deciding the Num of repeats - Sub 2:
#Measurement1 :
lab_Center_mean_Flowtime_data_without_warmUpTime <- lab_center_mean_Flowtime_Matrix[,(warmup_time+1):days] # delete data from warm up time
lab_Center_mean_Flowtime_vector_per_repeat_Sub2 <- apply(lab_Center_mean_Flowtime_data_without_warmUpTime,2,mean) # avg of all days in which repeat
test_mean_flowtime <- t.test(x= lab_Center_mean_Flowtime_vector_per_repeat_Sub2,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_flowtime<-(test_mean_flowtime$conf.int[2]-test_mean_flowtime$conf.int[1])/2
meanFlow <- test_mean_flowtime$estimate
Relative_accuracy_flowtime <-half_ci_flowtime/meanFlow
half_ci_flowtime
meanFlow
Relative_accuracy_flowtime

#Measurement2 :
Urgent_North_Mean_Queue_data_without_warmUpTime <- Urgent_north_mean_Queue_Matrix[,(warmup_time+1):days]
Urgent_North_Mean_Queue_Vector_per_repeat_Sub2 <- apply(Urgent_North_Mean_Queue_data_without_warmUpTime,2,mean)
test_mean_queue <- t.test(x= Urgent_North_Mean_Queue_Vector_per_repeat_Sub2,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_mean_queue <- (test_mean_queue$conf.int[2]-test_mean_queue$conf.int[1])/2 
meanQueue <- test_mean_queue$estimate
Relative_accuracy_meanqueue <-half_ci_mean_queue/meanQueue
half_ci_mean_queue
meanQueue
Relative_accuracy_meanqueue

#Measurement3:
Ambulance_Avg_Waitingtime_Data_without_warmUpTime <- avg_ambulacne_waiting_matrix[,(warmup_time+1):days]
Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub2 <- apply(Ambulance_Avg_Waitingtime_Data_without_warmUpTime,2,mean)
test_waitingTime <- t.test(x= Ambulance_Avg_Waitingtime_Vector_Per_repeat_Sub2,y=NULL, alternative="two.sided",conf.level=0.983)
half_ci_waitingTime <- (test_waitingTime$conf.int[2]-test_waitingTime$conf.int[1])/2 
meanWaitingTime <- test_waitingTime$estimate
Relative_accuracy_meanWaitingTime <-half_ci_waitingTime/meanWaitingTime
half_ci_waitingTime
meanWaitingTime
Relative_accuracy_meanWaitingTime


